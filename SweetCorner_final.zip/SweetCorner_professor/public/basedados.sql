-- --------------------------------------------------------
-- Anfitrião:                    127.0.0.1
-- Versão do servidor:           10.4.32-MariaDB - mariadb.org binary distribution
-- SO do servidor:               Win64
-- HeidiSQL Versão:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- A despejar estrutura da base de dados para sweetcorner
DROP DATABASE IF EXISTS `sweetcorner`;
CREATE DATABASE IF NOT EXISTS `sweetcorner` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `sweetcorner`;

-- A despejar estrutura para tabela sweetcorner.dias
DROP TABLE IF EXISTS `dias`;
CREATE TABLE IF NOT EXISTS `dias` (
  `id_player` int(5) DEFAULT NULL,
  `dia` int(5) NOT NULL,
  `temperatura` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela sweetcorner.dias: ~10 rows (aproximadamente)
INSERT INTO `dias` (`id_player`, `dia`, `temperatura`) VALUES
	(1, 1, 39),
	(11, 2, 17),
	(31, 1, 39),
	(32, 1, 39),
	(33, 1, 39),
	(34, 1, 39),
	(35, 1, 39),
	(36, 1, 39),
	(39, 1, 39),
	(40, 1, 39);

-- A despejar estrutura para tabela sweetcorner.pedidos_outono
DROP TABLE IF EXISTS `pedidos_outono`;
CREATE TABLE IF NOT EXISTS `pedidos_outono` (
  `id_player` int(11) DEFAULT NULL,
  `pedido` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela sweetcorner.pedidos_outono: ~6 rows (aproximadamente)
INSERT INTO `pedidos_outono` (`id_player`, `pedido`) VALUES
	(11, 'Coffee'),
	(11, 'Milk'),
	(11, 'Croissant'),
	(11, 'Muffin'),
	(11, 'Cupcake'),
	(11, 'Panike');

-- A despejar estrutura para tabela sweetcorner.pedidos_primavera
DROP TABLE IF EXISTS `pedidos_primavera`;
CREATE TABLE IF NOT EXISTS `pedidos_primavera` (
  `pedido` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela sweetcorner.pedidos_primavera: ~2 rows (aproximadamente)
INSERT INTO `pedidos_primavera` (`pedido`) VALUES
	('Coffee'),
	('Glass of milk'),
	('Muffin');

-- A despejar estrutura para tabela sweetcorner.pedidos_verao
DROP TABLE IF EXISTS `pedidos_verao`;
CREATE TABLE IF NOT EXISTS `pedidos_verao` (
  `pedido` varchar(250) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela sweetcorner.pedidos_verao: ~5 rows (aproximadamente)
INSERT INTO `pedidos_verao` (`pedido`) VALUES
	('Coffee'),
	('Glass of milk'),
	('Croissant'),
	('Cupcake'),
	('Muffin');

-- A despejar estrutura para tabela sweetcorner.produtos
DROP TABLE IF EXISTS `produtos`;
CREATE TABLE IF NOT EXISTS `produtos` (
  `id_produto` int(11) NOT NULL,
  `id_player` int(11) NOT NULL,
  `nome_produto` varchar(50) NOT NULL,
  `preco` int(11) NOT NULL DEFAULT 0,
  `quantidade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela sweetcorner.produtos: ~7 rows (aproximadamente)
INSERT INTO `produtos` (`id_produto`, `id_player`, `nome_produto`, `preco`, `quantidade`) VALUES
	(1, 11, 'Coffee Cup', 1, -53),
	(2, 11, 'Milk', 1, -11),
	(3, 11, 'Sugar', 1, 5),
	(4, 11, 'Coffee', 2, 5),
	(5, 11, 'Croissant', 2, 47),
	(6, 11, 'Muffin', 2, 0),
	(8, 11, 'CupCake', 1, -1);

-- A despejar estrutura para tabela sweetcorner.produtos_inverno
DROP TABLE IF EXISTS `produtos_inverno`;
CREATE TABLE IF NOT EXISTS `produtos_inverno` (
  `pedido` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela sweetcorner.produtos_inverno: ~3 rows (aproximadamente)
INSERT INTO `produtos_inverno` (`pedido`) VALUES
	('Coffee'),
	('Glass of milk'),
	('Croissant');

-- A despejar estrutura para tabela sweetcorner.receita
DROP TABLE IF EXISTS `receita`;
CREATE TABLE IF NOT EXISTS `receita` (
  `id_player` int(11) DEFAULT NULL,
  `id_produto` int(11) DEFAULT NULL,
  `quantidade_produto` int(11) DEFAULT NULL,
  `quantidade_produto_atual` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela sweetcorner.receita: ~21 rows (aproximadamente)
INSERT INTO `receita` (`id_player`, `id_produto`, `quantidade_produto`, `quantidade_produto_atual`) VALUES
	(11, 2, 0, 2),
	(11, 3, 0, 1),
	(11, 4, 0, 2),
	(33, 2, 0, 0),
	(33, 3, 0, 0),
	(33, 4, 0, 0),
	(34, 2, 0, 0),
	(34, 3, 0, 0),
	(34, 4, 0, 0),
	(35, 2, 0, 0),
	(35, 3, 0, 0),
	(35, 4, 0, 0),
	(36, 2, 0, 0),
	(36, 3, 0, 0),
	(36, 4, 0, 0),
	(39, 2, 0, 0),
	(39, 3, 0, 0),
	(39, 4, 0, 0),
	(40, 2, 0, 0),
	(40, 3, 0, 0),
	(40, 4, 0, 0);

-- A despejar estrutura para tabela sweetcorner.utilizadores
DROP TABLE IF EXISTS `utilizadores`;
CREATE TABLE IF NOT EXISTS `utilizadores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_cafe` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `xp` int(255) NOT NULL,
  `dia_utilizador` int(100) NOT NULL,
  `dinheiro_inicial` int(100) NOT NULL,
  `dinheiro_inicio_dia` int(100) NOT NULL,
  `dinheiro_atual` int(100) NOT NULL,
  `estacao` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- A despejar dados para tabela sweetcorner.utilizadores: ~2 rows (aproximadamente)
INSERT INTO `utilizadores` (`id`, `nome_cafe`, `email`, `password`, `xp`, `dia_utilizador`, `dinheiro_inicial`, `dinheiro_inicio_dia`, `dinheiro_atual`, `estacao`) VALUES
	(11, '', '', '', 50, 1, 1000, 8, 0, NULL),
	(31, '2', '2', '2', 0, 0, 30, 0, 0, NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
