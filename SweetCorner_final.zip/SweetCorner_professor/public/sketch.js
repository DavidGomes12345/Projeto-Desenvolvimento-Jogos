let scene = 0;

//images
let imgScene0;
let imgScene4;
let imgScene5;
let imgScene6;
let imgScene7;
let imgScene8;
let imgScene8_2;
let imgScene9;
let imgScene10;
let imgScene11;
let imgScene13;
let imgScene12;
let imgLogin;
let imgFundoScenePersonagens;
let imgsPersonagens= []; //will contain images of characters in gameScene
let imgNerd;

//buttons
let btnPlay;
let btnCredits;
let btnLeaderboard;
let btnBack;
let btnNext;
let btnStartNewDay;
let btnInventory1;
let btnInventory2;
let btnBuy1;
let btnBuy2;
let btnBuy3;
let btnBuy4;
let btnBuy5;
let btnBuy6;
let btnBuy7;
let btnBuy8;
let btnNext1;
let btnViewProfile;


//AUTHENTICATION VARIABLE
let registerBtn;
let loginBtn;
let nome_cafeInput;
let emailInput;
let passwordInput;

//PopUp
let LoginPopup;
let popupLoginConfirmacao;

//used in LeaderboardScene
let dataLeaderboard = [{}];
let arrLeaderboard = [];
let arrCardsLeaderboard= [];
let popupDinheiro;

let arrProdutos=[];
let arrDinheiro =[];
let dataServer = [{}];

let dataPedidos = [{}];
let arrPedidos = [];
let arrCardsPedidos = [];
let arrayPedidos = [];

let arrCards=[];
let arrCardsDinheiro = [];
let arrTabela = [];
let arrCardsTabela = [];

let dataRecipe = [{}];

let popup;


let numInputs = 4;
let inputs = [];
let InputCoffee = [];

let objetos = [];
let contadorObjetos = 0;
let gerarObjetos = false;

let startTime;
let rectangleVisible = true;

//------------
let milk;
let coffee;
let sugar;


//responsiveness
const referenceSize = 800;
const hasMaxSize = true;
const isCentered = true;
let canvasSize;
let windowScale;
let fullScreen;
let released = true;

let produto = {
  "id_player":1,
  "id_produto": "x",
  "quantidade":1
}

let dinheiro = {
  "id_player":1,
  "dinheiro":"1",
}

let i = 10

let botao;
let timerInterval;

function StartTimer () {
  timerInterval = setInterval(() => {
      if (gerarObjetos && contadorObjetos < i) {
        criarObjeto();
        contadorObjetos++;
      } else {
        gerarObjetos = false;
      }
    }, 5000);
};

function StopTimer() {
  clearInterval(timerInterval);
}

function preload() {
    imgScene0 = loadImage('/Imagens/1.jpg'); //homeScene
    imgScene4 = loadImage('/Imagens/2.jpg'); //tutorialFirstScene
    imgScene5 = loadImage('/Imagens/3.jpg');  //tutorialSecondScene
    imgScene6 = loadImage('/Imagens/4.jpg'); //tutorialThirdScene
    imgScene7 = loadImage('/Imagens/5.jpg'); //tutorialForthScene
    imgScene8 = loadImage('/Imagens/6.jpeg'); //inventoryScene
    imgScene8_2 = loadImage('/Imagens/6_pag2.jpg');
    imgScene9 = loadImage('/Imagens/9_receita.jpg') //coffeeScene
    imgScene10 = loadImage('/Imagens/7.png'); //dataScene
    imgScene11 = loadImage('/Imagens/8.png');
    imgScene12 = loadImage('/Imagens/12.jpg');
    imgScene13 = loadImage('/Imagens/13.jpg');
    imgLogin = loadImage('Imagens/img_Login.png');
    imgsPersonagens[0]=loadImage('/Imagens/Personagem_0.png');
    imgsPersonagens[1]=loadImage('/Imagens/Personagem_1.png');
    imgsPersonagens[2]=loadImage('/Imagens/Personagem_2.png');
    imgsPersonagens[3]=loadImage('/Imagens/Personagem_3.png');
    imgFundoScenePersonagens= loadImage('Imagens/FrenteDeLoja.jpg');
    imgNerd = loadImage('Imagens/nerd.png');
    imgBalao = loadImage('Imagens/balao.png');
}

function setup() {
    createCanvas(windowWidth,windowHeight); //nosso canva é do tamanho do ecrã do jogador
    popup=new PopUp();
    popupDinheiro = new PopUp_Dinheiro();
    LoginPopup = new PopUp_Login();
    BtnComprar = new Button();
    popupTabela = new PopUp_Tabela();
    popupLoginConfirmacao = new PopUp_ConfirmacaoLogin();

    //responsiveness
    setDimensions();
    if (isCentered) {
      centerCanvas();
    }
    createProducts()
    createInterface();
    createTabela();
    headerMenu();
    createLeaderboard();  
}

function draw() {
  
    if(scene==0){
        homeScene();
    } else if(scene==1){
        loginScene();
    } else if(scene==2){
        leaderboardScene();
    } else if(scene==3){
        creditsScene();
    } else if(scene==4){
        tutorialFirstScene();
    } else if(scene==5){
        tutorialSecondScene();
    } else if(scene==6){
        tutorialThirdScene();
    } else if(scene==7){
        tutorialForthScene();
    } else if(scene==8){
        inventoryScene();
    } else if(scene==9){
        coffeeScene();
    } else if(scene==10){
        gameScene();
    } else if(scene==11){
        dataScene();
    } else if(scene==12){
        inventoryScene2();
    } else if(scene == 13){
        WarningScene();
    } else if(scene == 14){
        ProfitDayScene();
    } else if(scene == 15){
        LossDayScene();
    } else if((scene == 16)){
        NoProfitNoLossScene();
    } else if (scene == 17){
      ViewOtherPlayerProfile();
    }
    
    if(scene!=10){
      noLoop();
    } 
  }

//Scene = 0
function homeScene(){
  push();
      image(imgScene0,0,0,width,height);
      btnPlay = new Button("Play",width*0.24,height*0.55,100,100);
      btnPlay.draw_Button();
      btnCredits = new Button("Credits",width*0.13,height*0.8,100,100);
      btnCredits.draw_Button();
      btnLeaderboard = new Button("Leaderboard",width*0.24,height*0.65,100,100);
      btnLeaderboard.draw_Button();
      loop();
  pop();
}

//LOGIN E REGISTO
function register(){
    let nome_cafe = nome_cafeInput.value();
    let email = emailInput.value();
    let password = passwordInput.value();
    
  
    let utilizadores = {
      "nome_cafe":nome_cafe,
      "email":email,
      "password":password,
    }
  
    httpPost('/register',utilizadores,'json',(respostaServidor)=>{
      if(respostaServidor.ack==0){
        textSize(20)
        rect(width*0.32,height*0.75,width*0.3,height*0.1,100);
        text("Unsuccessful registration, Already Exists",width*0.383,height*0.805)
        setTimeout(() => {
          removeElements();
          scene=1;
          loop();
        }, 2000);
       }else{
        textSize(20)
        rect(width*0.32,height*0.75,width*0.3,height*0.1,100);;
        text("Registration completed successfully",width*0.39,height*0.805)
        setTimeout(() => {
          removeElements();
          scene=1;
          loop();
        }, 2000);
    }});
}

function login(){

    let nome_cafe = nome_cafeInput.value();
    let email = emailInput.value();
    let password = passwordInput.value();
  
    let utilizadores = {
        "nome_cafe":nome_cafe,
        "email": email,
        "password":password
      }
  
    httpPost('/login', utilizadores,'json',(respostaServidor)=>{
  
        if(respostaServidor.length>0){
            utilizadores = respostaServidor;
            loadJSON("/getInformation/"+utilizadores[0].id,(respostaServidor) => {
                dataServer = dataServer.concat(respostaServidor);
              });
              loadJSON('/getRecipe/'+utilizadores[0].id, (dataDoServidor) => {
                dataRecipe = dataRecipe.concat(dataDoServidor);
                });
              textSize(20)
              rect(width*0.37,height*0.75,width*0.2,height*0.1,100);
              text("Login successfully",width*0.426,height*0.805);
              setTimeout(() => {
                removeElements();
                scene=4;
                loop();
              }, 2000);
            }else{
              textSize(20)
              rect(width*0.37,height*0.75,width*0.2,height*0.1,100);
              text("Login unsuccessfully",width*0.424,height*0.805)
              setTimeout(() => {
                removeElements();
                scene=1;
                loop();
              }, 2000);
            }
    
        });
}


//buscar informações à base de dados
function headerMenu(){
    loadJSON('/getLeaderboard/:id', (dataDoServidor) => {
      dataLeaderboard = dataLeaderboard.concat(dataDoServidor);
    });
}

function getProdutos(){
  let id_user = dataServer[1].id;
  loadJSON("/getProdutos/" + id_user,(datadoServidor) => {
      produto.nome_produto = datadoServidor[0].nome_produto;
      produto.quantidade = datadoServidor[0].quantidade;
  })
}

function getProdutos1(){
  let id_user = dataServer[1].id;
  loadJSON("/getProdutos/"+ id_user,(datadoServidor) => {
      produto.nome_produto1 = datadoServidor[1].nome_produto;
      produto.quantidade1 = datadoServidor[1].quantidade;
  })
}

function getProdutos2(){
  let id_user = dataServer[1].id;
  loadJSON("/getProdutos/"+ id_user,(datadoServidor) => {
      produto.nome_produto2 = datadoServidor[2].nome_produto;
      produto.quantidade2 = datadoServidor[2].quantidade;
  })
}

function getProdutos3(){
  let id_user = dataServer[1].id;
  loadJSON("/getProdutos/"+ id_user,(datadoServidor) => {
      produto.nome_produto3 = datadoServidor[3].nome_produto;
      produto.quantidade3 = datadoServidor[3].quantidade;
  })
}

function getProdutos4(){
  let id_user = dataServer[1].id;
  loadJSON("/getProdutos/"+ id_user,(datadoServidor) => {
      produto.nome_produto4 = datadoServidor[4].nome_produto;
      produto.quantidade4 = datadoServidor[4].quantidade;
  })
}

function getProdutos5(){
  let id_user = dataServer[1].id;
  loadJSON("/getProdutos/"+ id_user,(datadoServidor) => {
      produto.nome_produto5 = datadoServidor[5].nome_produto;
      produto.quantidade5 = datadoServidor[5].quantidade;
  })
}

function getProdutos6(){
  let id_user = dataServer[1].id;
  loadJSON("/getProdutos/"+ id_user,(datadoServidor) => {
      produto.nome_produto6 = datadoServidor[6].nome_produto;
      produto.quantidade6 = datadoServidor[6].quantidade;
  })
}

function getProdutos7(){
  let id_user = dataServer[1].id;
  loadJSON("/getProdutos/"+ id_user,(datadoServidor) => {
      produto.nome_produto7 = datadoServidor[7].nome_produto;
      produto.quantidade7 = datadoServidor[7].quantidade;
  })
}

function headerPedidos(){
  let id_user = dataServer[1].id;
  loadJSON('/getPedidos/' + id_user, (dataDoServidor) => {
    let pedidos = dataDoServidor;
    for(let i = 0; i < pedidos.length; i++ ) {
      let pedido = pedidos[i].pedido;
      arrayPedidos.push(pedido);
    }
  });
}

//____________SCENES____________\\

//Scene = 1
function loginScene(){
    push();
        clear();
        background(255);
        image(imgFundoScenePersonagens,0,0,width,height);
        
        LoginPopup.draw_PopUp_Login();
        image(imgLogin,width*0.51,height*0.13,width*0.175,height*0.54);

        textSize(25)
        text("Welcome to Sweet Corner",width*0.33,height*0.17);
        fill(0);

        nome_cafeInput = createInput('');
        nome_cafeInput.style('font-size','25px');
        textSize(20)
        text("Coffee Shop Name",width*0.34,height*0.23);
        nome_cafeInput.position(width*0.33,height*0.25);

        emailInput = createInput('');
        emailInput.style('font-size','25px');
        textSize(20)
        text("Email",width*0.34,height*0.33);
        emailInput.position(width*0.33,height*0.35);
    
        passwordInput = createInput('');
        passwordInput.style('font-size','25px');
        textSize(20);
        text("Password",width*0.34,height*0.43);
        passwordInput.position(width*0.33,height*0.45);
        
        loginBtn = createButton('LOGIN');
        loginBtn.position(width*0.33,height*0.52);
        loginBtn.size(width*0.167,height*0.04)
        loginBtn.mousePressed(login);

        textSize(15);
        text("Not registered?",width*0.38,height*0.6);

        registerBtn = createButton('REGISTER');
        registerBtn.position(width*0.33,height*0.615);
        registerBtn.size(width*0.167,height*0.04)
        registerBtn.mousePressed(register);
        loop();

    pop();
}

//Scene = 2
function leaderboardScene(){
  clear();
  push();
  background(255);
  image(imgScene11,0,0,width,height);
  btnBack = new Button("Back",width*0.23,height*0.87,100,100);
  btnBack.draw_Button();

  rect(width*0.1,height*0.1,width*0.77 ,height*0.08,30);
  textSize(25)
  text("Id Player",width*0.165,height*0.15);
  text("Coffee Name",width*0.33,height*0.15);
  text("XP",width*0.54,height*0.15);
  text("Current Day",width*0.635,height*0.15);
  text("Current Money",width*0.73,height*0.15);

  createLeaderboard();
  createInterfaceLeaderboard();
  drawInterfaceLeaderboard();

  pop();
  loop();

}

//Scene = 3
function creditsScene(){
    clear();
    background(255);
    image(imgScene11,0,0,width,height);
    btnBack = new Button("Back",width*0.23,height*0.87,100,100);
    btnBack.draw_Button();

    rect(width*0.25,height*0.25,width*0.5,height*0.5,30);
    textSize(22);
    text("Jogo desenvolvido por:",width*0.45,height*0.3)
    image(imgNerd,windowWidth*0.325,height/2.2,150,150);
    text("David Gomes - 48537",width/3.25,height/1.5);
    image(imgNerd,windowWidth*0.58,height/2.2,150,150);
    text("Cristina Monteiro - 47592",width*0.55,height/1.5);
    loop();
}

//Scene = 4
function tutorialFirstScene(){
    clear();
    background(255);
    image(imgScene4,0,0,width,height);
    fill(255);
    btnNext = new Button("Skip",width*0.8,height*0.87,100,100);
    btnNext.draw_Button();
    headerPedidos();
    getProdutos();
    getProdutos1()
    getProdutos2();
    getProdutos3();
    getProdutos4()
    getProdutos5();
    getProdutos6();
    getProdutos7();
}

//Scene = 5
function tutorialSecondScene(){
    clear();
    background(255);
    image(imgScene5,0,0,width,height);
    btnNext = new Button("Skip",width*0.8,height*0.87,100,100);
    btnNext.draw_Button();
    popupDinheiro.draw_PopUpDinheiro(); 
    createDinheiro();
    createInterfaceDinheiro();
    drawInterfaceDinheiro();
    btnBack = new Button("Back",width*0.23,height*0.87,100,100);
    btnBack.draw_Button();
}

//Scene = 6
function tutorialThirdScene(){
    clear();
    background(255);
    image(imgScene6,0,0,width,height);
    btnNext = new Button("Skip",width*0.8,height*0.87,100,100);
    btnNext.draw_Button();
    popupDinheiro.draw_PopUpDinheiro(); 
    createDinheiro();
    createInterfaceDinheiro();
    drawInterfaceDinheiro();
    btnBack = new Button("Back",width*0.23,height*0.87,100,100);
    btnBack.draw_Button();
}

//Scene = 7
function tutorialForthScene(){
    clear();
    background(255);
    image(imgScene7,0,0,width,height);
    btnNext = new Button("Next",width*0.8,height*0.87,100,100);
    btnNext.draw_Button();
    popupDinheiro.draw_PopUpDinheiro(); 
    createDinheiro();
    createInterfaceDinheiro();
    drawInterfaceDinheiro();
    btnBack = new Button("Back",width*0.23,height*0.87,100,100);
    btnBack.draw_Button();
}

//Scene = 8
function inventoryScene(){
    clear();
    background(255);
    push();
    image(imgScene8,0,0,width,height);
    textSize(25)
    fill("#000000")
    text("Name",width*0.33,height*0.35);
    text("Price",width*0.485,height*0.35);
    text("Quantity",width*0.67,height*0.35);
    createProducts()
    createInterface()
    drawInterface();
    popupDinheiro.draw_PopUpDinheiro(); 
    createDinheiro();
    createInterfaceDinheiro();
    drawInterfaceDinheiro();
    //headerBuscarNovasInformacoes();

    generateInput();

    btnBuy1 = new ButtonBuy("Buy",width*0.744,height*0.405);
    btnBuy1.draw_Button_Buy();

    btnBuy2 = new ButtonBuy("Buy",width*0.744,height*0.515);
    btnBuy2.draw_Button_Buy();

    btnBuy3 = new ButtonBuy("Buy",width*0.744,height*0.625);
    btnBuy3.draw_Button_Buy();

    btnBuy4 = new ButtonBuy("Buy",width*0.744,height*0.735);
    btnBuy4.draw_Button_Buy();

    textSize(30);
    text("<",width*0.47,height*0.873);
    text(">",width*0.53,height*0.873);

    btnInventory1 = new ButtonSmallInventory("1",width*0.49,height*0.86);
    btnInventory1.draw_Button_Small();

    if(arrProdutos.length >= 6){
      btnInventory2 = new ButtonSmallInventory("2",width*0.51,height*0.86);
      btnInventory2.draw_Button_Small();
    }

    btnNext = new Button("Next",width*0.8,height*0.87,100,100);
    btnNext.draw_Button();

    btnBack = new Button("Back",width*0.23,height*0.87,100,100);
    btnBack.draw_Button();
    pop();
}

//scene = 12
function inventoryScene2(){
    clear();
    background(255);
    push();
    image(imgScene8_2,0,0,width,height);
    textSize(25)
    fill("#000000")
    text("Name",width*0.33,height*0.35);
    text("Price",width*0.485,height*0.35);
    text("Quantity",width*0.67,height*0.35);
    createProducts()
    createInterface2()
    drawInterface2();
    popupDinheiro.draw_PopUpDinheiro(); 
    createDinheiro();
    createInterfaceDinheiro();
    drawInterfaceDinheiro();

    generateInput();

    btnBuy5 = new ButtonBuy("Buy",width*0.744,height*0.405);
    btnBuy5.draw_Button_Buy();

    if(dataServer.length == 7){
      btnBuy6 = new ButtonBuy("Buy",width*0.744,height*0.515)
      btnBuy6.draw_Button_Buy();
    }
    if(dataServer.length == 8){
      btnBuy6 = new ButtonBuy("Buy",width*0.744,height*0.515)
      btnBuy7 = new ButtonBuy("Buy",width*0.744,height*0.625);
      btnBuy7.draw_Button_Buy();
    }

    if(dataServer.length == 9) {
      btnBuy6 = new ButtonBuy("Buy",width*0.744,height*0.515);
      btnBuy6.draw_Button_Buy();
      btnBuy7 = new ButtonBuy("Buy",width*0.744,height*0.625);
      btnBuy7.draw_Button_Buy();
      btnBuy8 = new ButtonBuy("Buy",width*0.744,height*0.735);
      btnBuy8.draw_Button_Buy();
    }
    textSize(30);
    text("<",width*0.47,height*0.873);
    text(">",width*0.53,height*0.873);

    btnInventory1 = new ButtonSmallInventory("1",width*0.49,height*0.86);
    btnInventory1.draw_Button_Small();

    btnInventory2 = new ButtonSmallInventory("2",width*0.51,height*0.86);
    btnInventory2.draw_Button_Small();

    btnNext = new Button("Next",width*0.8,height*0.87,100,100);
    btnNext.draw_Button();

    btnBack = new Button("Back",width*0.23,height*0.87,100,100);
    btnBack.draw_Button();
    pop();
}

//Scene = 9
function coffeeScene(){
  clear();
  removeElements();
  background(255);
  image(imgScene9,0,0,width,height);
  popupDinheiro.draw_PopUpDinheiro(); 
  createDinheiro();
  createInterfaceDinheiro();
  drawInterfaceDinheiro();
  textSize(20);
  fill(0)
  text("Write the amount of each ingredient so that it is perfect.",width*0.4,height*0.33);

  generateInput2();

  btnNext = new Button("Next",width*0.8,height*0.87,100,100);
  btnNext.draw_Button();
}

//Scene = 10
function gameScene(){
    clear();
    removeElements();
    push();
    background(255);
    image(imgScene10,0,0,width,height);

    if(frameCount === 50){
      gerarObjetos = true;
      StartTimer();
    }

    // Atualiza e exibe todos os objetos existentes
    for (let i = objetos.length - 1; i >= 0; i--) {
        objetos[i].atualizar();
        objetos[i].exibir();
        objetos[i].pedidos();

    // Remove o objeto se ele atingir o final da tela após o tempo de espera no centro
    if (objetos[i].chegouAoFim()) {
      objetos.splice(i, 1);
    }
    }
    fill("#FFFFFF");
    rect(5,height*0.68,width*0.22,height*0.3,30);
    fill("#FFFFFF");
    rect(width*0.02,height*0.683,width*0.085,height*0.04,30);

    fill("#000000")
    text("Inventory",width*0.04,height*0.71)
    textSize(18)
    text("Quantity",width*0.15,height*0.71)

    text(produto.nome_produto,width*0.02,height*0.75);
    text(produto.quantidade,width*0.16,height*0.75);
  
    text(produto.nome_produto1,width*0.02,height*0.775);
    text(produto.quantidade1, width*0.16,height*0.775);
  
    text(produto.nome_produto2,width*0.02,height*0.800);
    text(produto.quantidade2,width*0.16,height*0.800);
  
    text(produto.nome_produto3,width*0.02,height*0.825);
    text(produto.quantidade3,width*0.16,height*0.825);

    if(dataServer.length == 6) {

      text(produto.nome_produto4,width*0.02,height*0.850);
      text(produto.quantidade4,width*0.16,height*0.850);

    }

    if(dataServer.length == 7) {

      text(produto.nome_produto4,width*0.02,height*0.850);
      text(produto.quantidade4,width*0.16,height*0.850);
      
      text(produto.nome_produto5,width*0.02,height*0.875);
      text(produto.quantidade5,width*0.16,height*0.875);

    }

    if(dataServer.length == 8) {

      text(produto.nome_produto4,width*0.02,height*0.850);
      text(produto.quantidade4,width*0.16,height*0.850);
      
      text(produto.nome_produto5,width*0.02,height*0.875);
      text(produto.quantidade5,width*0.16,height*0.875);

      text(produto.nome_produto6,width*0.02,height*0.900);
      text(produto.quantidade6,width*0.16,height*0.900);

    }

    if(dataServer.length == 9) {

      text(produto.nome_produto4,width*0.02,height*0.850);
      text(produto.quantidade4,width*0.16,height*0.850);
      
      text(produto.nome_produto5,width*0.02,height*0.875);
      text(produto.quantidade5,width*0.16,height*0.875);

      text(produto.nome_produto6,width*0.02,height*0.900);
      text(produto.quantidade6,width*0.16,height*0.900);

      text(produto.nome_produto7,width*0.02,height*0.925);
      text(produto.quantidade7,width*0.16,height*0.925);

    }

    popupDinheiro.draw_PopUpDinheiro(); 
    createDinheiro();
    createInterfaceDinheiro();
    drawInterfaceDinheiro();

    btnNext = new Button("Next",width*0.8,height*0.87,100,100);
    btnNext.draw_Button();

    pop();
}

//Scene = 11
function dataScene(){
  clear();
  background(255);
  image(imgScene11,0,0,width,height);
  fill("#ffffff")
  popupDinheiro.draw_PopUpDinheiro(); 
  createDinheiro();
  createInterfaceDinheiro();
  drawInterfaceDinheiro();

 
  drawChart(width / 2, height / 2.5);


  btnNext = new Button("Next",width*0.8,height*0.87,100,100);
  btnNext.draw_Button();
}

//Scene = 13
function WarningScene() {
  clear();
  removeElements();
  background(255);
  image(imgScene9,0,0,width,height);
  popupDinheiro.draw_PopUpDinheiro(); 
  createDinheiro();
  createInterfaceDinheiro();
  drawInterfaceDinheiro();
  fill("#FFFFFF")
      rect(width*0.25,height*0.2,width*0.5,height*0.6,30);
      noStroke();
      fill("#000000")
      text("The chosen quantities were:", width*0.3,height*0.3);
      text("Milk - " + milk + " units", width*0.3,height*0.35)
      text("Coffee - " + coffee + " units", width*0.3,height*0.38)
      text("Sugar - " + sugar + " units", width*0.3,height*0.41)
      
      fill("#FFFFFF")
      stroke(20);
      rect(width*0.26,height*0.45,width*0.48,height*0.1,30)
      noStroke();
      fill("#000000") 
      text("The quantities chosen influence the quantity of products that will be sold by each coffee.",width*0.3,height*0.5)
      

      text("Do you intend to continue with these updates? ",width*0.4,height*0.65)
      btnNext1 = new Button("Yes",width*0.6,height*0.7,100,100);
      btnNext1.draw_Button();
  
      btnBack = new Button("No",width*0.4,height*0.7,100,100);
      btnBack.draw_Button();
}

function ProfitDayScene(){ 
  clear();
    background(255);
    image(imgScene13,0,0,width,height);
    btnNext = new Button("Next",width*0.8,height*0.87,100,100);
    btnNext.draw_Button();

    profitLoss = dataServer[1].dinheiro_atual - dataServer[1].dinheiro_inicio_dia;
    popup1 = new Card_Popup_ProfitLossScenes(width*0.5,height*0.35,"Awesome job, keep going!" , `You had a profit of ${profitLoss} and won 5 xp.\n Quantos mais dias lucrativos mais clientes virão`);
    popup1.draw_Card_Popup_ProfitLossScenes();

    btnStartNewDay = new Button("Start a new day",width*0.8,height*0.87,100,100);
    btnStartNewDay.draw_Button();

    let novoxp_numero = int(dataServer[1].xp) + 5;

    let novoxp = {
      "id":dataServer[1].id,
      "xp":novoxp_numero,
    }
    httpPost('/enviarNovasInformacoesXP',novoxp,'json',(respostaServidor) => {
    });

    if(novoxp_numero == 20 ) {
      let novoId_Produto = int(dataServer[5].id_produto) + 1;

      let novoPedido = {
        "id":dataServer[1].id,
        "pedido":"Muffin",
      }

      httpPost('/enviarNovasInformacoesPedido',novoPedido,'json',(respostaServidor) => {
      });

      let novoProduto = {
        "id":dataServer[1].id,
        "produto":"Muffin",
        "id_produto":novoId_Produto,
        "preco":2,
        "quantidade":0,
      }

      httpPost('/enviarNovasInformacoesProduto',novoProduto,'json',(respostaServidor) => {
      });

    } else if(novoxp_numero == 40){
      
      let novoId_Produto = int(dataServer[6].id_produto) + 1;

      let novoPedido = {
        "id":dataServer[1].id,
        "pedido":"CupCake",
      }

      httpPost('/enviarNovasInformacoesPedido',novoPedido,'json',(respostaServidor) => {
      });

      let novoProduto = {
        "id":dataServer[1].id,
        "produto":"CupCake",
        "id_produto":novoId_Produto,
        "preco":2,
        "quantidade":0,
      }

      httpPost('/enviarNovasInformacoesProduto',novoProduto,'json',(respostaServidor) => {
      });
    } else if(novoxp_numero == 60){

      let novoId_Produto = int(dataServer[7].id_produto) + 1;
      
      let novoPedido = {
        "id":dataServer[1].id,
        "pedido":"Panike",
      }

      httpPost('/enviarNovasInformacoesPedido',novoPedido,'json',(respostaServidor) => {
      });

      let novoProduto = {
        "id":dataServer[1].id,
        "produto":"Panike",
        "id_produto":novoId_Produto,
        "preco":3,
        "quantidade":0,
      }

      httpPost('/enviarNovasInformacoesProduto',novoProduto,'json',(respostaServidor) => {
      });
    }

    novoDia_numero = int(dataServer[1].dia_utilizador) + 1;
    novaTemperatura = floor(random(0, 40));

    let novoDia = {
      "id":dataServer[1].id,
      "dia":novoDia_numero,
      "temperatura":novaTemperatura,
    }

    httpPost('/enviarNovasInformacoesDia',novoDia,'json',(respostaServidor) => {
    });

    if(novoDia == 6){

      let novaEstacao = {
        "id":dataServer[1].id,
        "estacao":"Primavera",
      }

      httpPost('/enviarNovasInformacoesEstacao',novaEstacao,'json',(respostaServidor) => {
      });
    } else if(novoDia == 11){

      let novaEstacao = {
        "id":dataServer[1].id,
        "estacao":"Verão",
      }

      httpPost('/enviarNovasInformacoesEstacao',novaEstacao,'json',(respostaServidor) => {
      });
    } else if(novoDia == 17){

      let novaEstacao = {
        "id":dataServer[1].id,
        "estacao":"Outono",
      }

      httpPost('/enviarNovasInformacoesEstacao',novaEstacao,'json',(respostaServidor) => {
      });
    } else if(novoDia == 23) {
      let novaEstacao = {
        "id":dataServer[1].id,
        "estacao":"Inverno",
      }

      httpPost('/enviarNovasInformacoesEstacao',novaEstacao,'json',(respostaServidor) => {
      });
    }
    
    let novoDinheiro_Base = dataServer[1].dinheiro_inicial + dataServer[1].dinheiro_atual;

    let dinheiro = {
      "id":dataServer[1].id,
      "dinheiro":novoDinheiro_Base,
      "dinheiro_antigo":0,
    }

    httpPost('/enviarNovasInformacoesDinheiro',dinheiro,'json',(respostaServidor) => {
    });
}

function NoProfitNoLossScene(){
  clear();
    background(255);
    image(imgScene13,0,0,width,height);
    btnNext = new Button("Next",width*0.8,height*0.87,100,100);
    btnNext.draw_Button();

    profitLoss = dataServer[1].dinheiro_atual - dataServer[1].dinheiro_inicio_dia;
    popup1 = new Card_Popup_ProfitLossScenes(width*0.5,height*0.35,"Mediocre job.","You didn't had any profit or loss and only won 3 xp\n because we are nice.");
    popup1.draw_Card_Popup_ProfitLossScenes();


    btnStartNewDay = new Button("Start a new day",width*0.8,height*0.87,100,100);
    btnStartNewDay.draw_Button();

    let novoxp_numero = int(dataServer[1].xp) + 2;

    let novoxp = {
      "id":dataServer[1].id,
      "xp":novoxp_numero,
    }
    httpPost('/enviarNovasInformacoesXP',novoxp,'json',(respostaServidor) => {
    });

    if(novoxp_numero == 20 ) {
      let novoId_Produto = int(dataServer[5].id_produto) + 1;

      let novoPedido = {
        "id":dataServer[1].id,
        "pedido":"Muffin",
      }

      httpPost('/enviarNovasInformacoesPedido',novoPedido,'json',(respostaServidor) => {
      });

      let novoProduto = {
        "id":dataServer[1].id,
        "produto":"Muffin",
        "id_produto":novoId_Produto,
        "preco":2,
        "quantidade":0,
      }

      httpPost('/enviarNovasInformacoesProduto',novoProduto,'json',(respostaServidor) => {
      });

    } else if(novoxp_numero == 40){
      
      let novoId_Produto = int(dataServer[6].id_produto) + 1;

      let novoPedido = {
        "id":dataServer[1].id,
        "pedido":"Panike",
      }

      httpPost('/enviarNovasInformacoesPedido',novoPedido,'json',(respostaServidor) => {
      });

      let novoProduto = {
        "id":dataServer[1].id,
        "produto":"Panike",
        "id_produto":novoId_Produto,
        "preco":2,
        "quantidade":0,
      }

      httpPost('/enviarNovasInformacoesProduto',novoProduto,'json',(respostaServidor) => {
      });
    } else if(novoxp_numero == 60){

      let novoId_Produto = int(dataServer[7].id_produto) + 1;
      
      let novoPedido = {
        "id":dataServer[1].id,
        "pedido":"CupCake",
      }

      httpPost('/enviarNovasInformacoesPedido',novoPedido,'json',(respostaServidor) => {
      });

      let novoProduto = {
        "id":dataServer[1].id,
        "produto":"CupCake",
        "id_produto":novoId_Produto,
        "preco":3,
        "quantidade":0,
      }

      httpPost('/enviarNovasInformacoesProduto',novoProduto,'json',(respostaServidor) => {
      });
    }

    novoDia_numero = int(dataServer[1].dia_utilizador) + 1;
    novaTemperatura = int(random(1, 40));

    let novoDia = {
      "id":dataServer[1].id,
      "dia":novoDia_numero,
      "temperatura":novaTemperatura,
    }

    httpPost('/enviarNovasInformacoesDia',novoDia,'json',(respostaServidor) => {
    });

    if(novoDia == 6){

      let novaEstacao = {
        "id":dataServer[1].id,
        "estacao":"Primavera",
      }

      httpPost('/enviarNovasInformacoesEstacao',novaEstacao,'json',(respostaServidor) => {
      });
    } else if(novoDia == 11){

      let novaEstacao = {
        "id":dataServer[1].id,
        "estacao":"Verão",
      }

      httpPost('/enviarNovasInformacoesEstacao',novaEstacao,'json',(respostaServidor) => {
      });
    } else if(novoDia == 17){

      let novaEstacao = {
        "id":dataServer[1].id,
        "estacao":"Outono",
      }

      httpPost('/enviarNovasInformacoesEstacao',novaEstacao,'json',(respostaServidor) => {
      });
    } else if(novoDia == 23) {
      let novaEstacao = {
        "id":dataServer[1].id,
        "estacao":"Inverno",
      }

      httpPost('/enviarNovasInformacoesEstacao',novaEstacao,'json',(respostaServidor) => {
      });
    }

    let novoDinheiro_Base = dataServer[1].dinheiro_inicial + dataServer[1].dinheiro_atual;

    let dinheiro = {
      "id":dataServer[1].id,
      "dinheiro":novoDinheiro_Base,
      "dinheiro_antigo":0,
    }

    httpPost('/enviarNovasInformacoesDinheiro',dinheiro,'json',(respostaServidor) => {
    });


}

function LossDayScene(){
  clear();
    background(255);
    image(imgScene12,0,0,width,height);
    btnNext = new Button("Next",width*0.8,height*0.87,100,100);
    btnNext.draw_Button();

    profitLoss = dataServer[1].dinheiro_atual - dataServer[1].dinheiro_inicio_dia;
    popup1 = new Card_Popup_ProfitLossScenes(width*0.5,height*0.35,"Terrible job, you lost money!" , `You had a loss of ${profitLoss} and only won 2 xp \nbecause we are nice.`);
    popup1.draw_Card_Popup_ProfitLossScenes();

    btnStartNewDay = new Button("Start a new day",width*0.8,height*0.87,100,100);
    btnStartNewDay.draw_Button();


    let novoxp_numero = int(dataServer[1].xp) + 2;

    let novoxp = {
      "id":dataServer[1].id,
      "xp":novoxp_numero,
    }
    httpPost('/enviarNovasInformacoesXP',novoxp,'json',(respostaServidor) => {
    });

    if(novoxp_numero == 20 ) {
      let novoId_Produto = int(dataServer[5].id_produto) + 1;

      let novoPedido = {
        "id":dataServer[1].id,
        "pedido":"Muffin",
      }

      httpPost('/enviarNovasInformacoesPedido',novoPedido,'json',(respostaServidor) => {
      });

      let novoProduto = {
        "id":dataServer[1].id,
        "produto":"Muffin",
        "id_produto":novoId_Produto,
        "preco":2,
        "quantidade":0,
      }

      httpPost('/enviarNovasInformacoesProduto',novoProduto,'json',(respostaServidor) => {
      });

    } else if(novoxp_numero == 40){
      
      let novoId_Produto = int(dataServer[6].id_produto) + 1;

      let novoPedido = {
        "id":dataServer[1].id,
        "pedido":"Panike",
      }

      httpPost('/enviarNovasInformacoesPedido',novoPedido,'json',(respostaServidor) => {
      });

      let novoProduto = {
        "id":dataServer[1].id,
        "produto":"Panike",
        "id_produto":novoId_Produto,
        "preco":2,
        "quantidade":0,
      }

      httpPost('/enviarNovasInformacoesProduto',novoProduto,'json',(respostaServidor) => {
      });
    } else if(novoxp_numero == 60){

      let novoId_Produto = int(dataServer[7].id_produto) + 1;
      
      let novoPedido = {
        "id":dataServer[1].id,
        "pedido":"CupCake",
      }

      httpPost('/enviarNovasInformacoesPedido',novoPedido,'json',(respostaServidor) => {
      });

      let novoProduto = {
        "id":dataServer[1].id,
        "produto":"CupCake",
        "id_produto":novoId_Produto,
        "preco":3,
        "quantidade":0,
      }

      httpPost('/enviarNovasInformacoesProduto',novoProduto,'json',(respostaServidor) => {
      });
    }

    novoDia_numero = int(dataServer[1].dia_utilizador) + 1;
    novaTemperatura = int(random(1, 40));

    let novoDia = {
      "id":dataServer[1].id,
      "dia":novoDia_numero,
      "temperatura":novaTemperatura,
    }

    httpPost('/enviarNovasInformacoesDia',novoDia,'json',(respostaServidor) => {
    });

    if(novoDia == 6){

      let novaEstacao = {
        "id":dataServer[1].id,
        "estacao":"Primavera",
      }

      httpPost('/enviarNovasInformacoesEstacao',novaEstacao,'json',(respostaServidor) => {
      });
    } else if(novoDia == 11){

      let novaEstacao = {
        "id":dataServer[1].id,
        "estacao":"Verão",
      }

      httpPost('/enviarNovasInformacoesEstacao',novaEstacao,'json',(respostaServidor) => {
      });
    } else if(novoDia == 17){

      let novaEstacao = {
        "id":dataServer[1].id,
        "estacao":"Outono",
      }

      httpPost('/enviarNovasInformacoesEstacao',novaEstacao,'json',(respostaServidor) => {
      });
    } else if(novoDia == 23) {
      let novaEstacao = {
        "id":dataServer[1].id,
        "estacao":"Inverno",
      }

      httpPost('/enviarNovasInformacoesEstacao',novaEstacao,'json',(respostaServidor) => {
      });
    }

    let novoDinheiro_Base = dataServer[1].dinheiro_inicial + dataServer[1].dinheiro_atual;

    let dinheiro = {
      "id":dataServer[1].id,
      "dinheiro":novoDinheiro_Base,
      "dinheiro_antigo":0,
    }

    httpPost('/enviarNovasInformacoesDinheiro',dinheiro,'json',(respostaServidor) => {
    });
}

function ViewOtherPlayerProfile(){
  clear();
    background(255);
    image(imgScene11,0,0,width,height);
    btnBack = new Button("Back",width*0.23,height*0.87,100,100);
    btnBack.draw_Button();

    //Codigo que permite visualizar os dados do player em que clicou
    popup1 = new Card_Popup_ViewOtherPlayerProfile(width*0.5,height*0.20);
    popup1.draw_Card_Popup_ViewOtherPlayerProfile();
    textSize(35);
    text("About the player",width*0.43,height*0.2);
    textSize(27);
    text("Coffee Shop:",width*0.35,height*0.3);
    text("Money:",width*0.35,height*0.35);
    text("XP:",width*0.35,height*0.4);
    text("Played days:",width*0.35,height*0.45);
}

// FUNÇÕES PARA IR BUSCAR VALORES E INCREMENTAR NA BASE DE DADOS

function getValues() {
  let value = inputs[0].getValue();

  let newDinheiro = dataServer[1].dinheiro_inicial - (value * dataServer[1].preco);
  if( newDinheiro <= 0){
    popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Not enough money");
    popup1.draw_Card_Popup_Inventario();
    setTimeout(() => {
      scene=8;
      loop();
    }, 3000);
  } else {
    let updateDinheiro = {
    "id": dataServer[1].id,
    "dinheiro_atual":newDinheiro,
  }

  let quantidadeValor = int(dataServer[1].quantidade) + int(value);

  let compras = {
    "id":dataServer[1].id,
    "compra": quantidadeValor,
    "id_produto":dataServer[1].id_produto,
  };

  httpPost('/enviarCompras',compras,'json',(respostaServidor) => {
  });

  httpPost('/enviarDinheiro',updateDinheiro,'json',(respostaServidor1) => {
  })

  popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Bought Coffee Cups");
  popup1.draw_Card_Popup_Inventario();
  setTimeout(() => {
    scene=8;
    loop();
  }, 3000);
  }
}

function getValues_1() {
  let value = inputs[1].getValue();

  let newDinheiro = dataServer[1].dinheiro_inicial - (value * dataServer[2].preco);
  if( newDinheiro <= 0){
    popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Not enough money");
    popup1.draw_Card_Popup_Inventario();
    setTimeout(() => {
      scene=8;
      loop();
    }, 3000);
  } else {
  let updateDinheiro = {
    "id": dataServer[1].id,
    "dinheiro_atual":newDinheiro,
  }

  let quantidadeValor = int(dataServer[2].quantidade) + int(value);

  let compras = {
    "id":dataServer[1].id,
    "compra": quantidadeValor,
    "id_produto":dataServer[2].id_produto,
  };

  httpPost('/enviarCompras',compras,'json',(respostaServidor) => {
  });

  httpPost('/enviarDinheiro',updateDinheiro,'json',(respostaServidor1) => {
  })
  popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Bought Milk");
  popup1.draw_Card_Popup_Inventario();
  setTimeout(() => {
    scene=8;
    loop();
  }, 3000);
}
}

function getValues_2() {
  let value = inputs[2].getValue();

  let newDinheiro = dataServer[3].dinheiro_inicial - (value * dataServer[3].preco);

  if( newDinheiro <= 0){
    popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Not enough money");
    popup1.draw_Card_Popup_Inventario();
    setTimeout(() => {
      scene=8;
      loop();
    }, 3000);
  } else {
  let updateDinheiro = {
    "id": dataServer[1].id,
    "dinheiro_atual":newDinheiro,
  }

  let quantidadeValor = int(dataServer[3].quantidade) + int(value);

  let compras = {
    "id":dataServer[1].id,
    "compra": quantidadeValor,
    "id_produto":dataServer[3].id_produto,
  };

  httpPost('/enviarCompras',compras,'json',(respostaServidor) => {
  });

  httpPost('/enviarDinheiro',updateDinheiro,'json',(respostaServidor1) => {
  })
  popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Bought Sugar");
  popup1.draw_Card_Popup_Inventario();
  setTimeout(() => {
    scene=8;
    loop();
  }, 3000);
}
}

function getValues_3() {
  let value = inputs[3].getValue();

  let newDinheiro = dataServer[1].dinheiro_inicial - (value * dataServer[4].preco);

  if( newDinheiro <= 0){
    popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Not enough money");
    popup1.draw_Card_Popup_Inventario();
    setTimeout(() => {
      scene=8;
      loop();
    }, 3000);
  } else {
  let updateDinheiro = {
    "id": dataServer[1].id,
    "dinheiro_atual":newDinheiro,
  }

  let quantidadeValor = int(dataServer[4].quantidade) + int(value);

  let compras = {
    "id":dataServer[1].id,
    "compra":quantidadeValor,
    "id_produto":dataServer[4].id_produto,
  };

  httpPost('/enviarCompras',compras,'json',(respostaServidor) => {
  });

  httpPost('/enviarDinheiro',updateDinheiro,'json',(respostaServidor1) => {
  })
  popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Bought Coffee");
  popup1.draw_Card_Popup_Inventario();
  setTimeout(() => {
    scene=8;
    loop();
  }, 3000);
}
}

function getValues_4() {
  let value = inputs[4].getValue();

  let newDinheiro = dataServer[1].dinheiro_inicial - (value * dataServer[5].preco);

  if( newDinheiro <= 0){
    popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Not enough money");
    popup1.draw_Card_Popup_Inventario();
    setTimeout(() => {
      scene=8;
      loop();
    }, 3000);
  } else {
  let updateDinheiro = {
    "id": dataServer[1].id,
    "dinheiro_atual":newDinheiro,
  }

  let quantidadeValor = int(dataServer[5].quantidade) + int(value);

  let compras = {
    "id":dataServer[1].id,
    "compra": quantidadeValor,
    "id_produto":dataServer[5].id_produto,
  };

  httpPost('/enviarCompras',compras,'json',(respostaServidor) => {
  });

  httpPost('/enviarDinheiro',updateDinheiro,'json',(respostaServidor1) => {
  })
  popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Bought Croissant");
  popup1.draw_Card_Popup_Inventario();
  setTimeout(() => {
    scene=8;
    loop();
  }, 3000);
}
}

function getValues_5(){
  let value = inputs[5].getValue();

  let newDinheiro = dataServer[1].dinheiro_inicial - (value * dataServer[6].preco);

  if( newDinheiro <= 0){
    popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Not enough money");
    popup1.draw_Card_Popup_Inventario();
    setTimeout(() => {
      scene=12;
      loop();
    }, 3000);
  } else {
  let updateDinheiro = {
    "id": dataServer[1].id,
    "dinheiro_atual":newDinheiro,
  }

  let quantidadeValor = int(dataServer[6].quantidade) + int(value);

  let compras = {
    "id":dataServer[1].id,
    "compra": quantidadeValor,
    "id_produto":dataServer[6].id_produto,
  };

  httpPost('/enviarCompras',compras,'json',(respostaServidor) => {
  });

  httpPost('/enviarDinheiro',updateDinheiro,'json',(respostaServidor1) => {
  })
  popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Bought Muffin");
  popup1.draw_Card_Popup_Inventario();
  setTimeout(() => {
    scene=12;
    loop();
  }, 3000);
}
}

function getValues_6(){
  let value = inputs[6].getValue();

  let newDinheiro = dataServer[1].dinheiro_inicial - (value * dataServer[7].preco);

  if( newDinheiro <= 0){
    popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Not enough money");
    popup1.draw_Card_Popup_Inventario();
    setTimeout(() => {
      scene=12;
      loop();
    }, 3000);
  } else {
  let updateDinheiro = {
    "id": dataServer[1].id,
    "dinheiro_atual":newDinheiro,
  }

  let quantidadeValor = int(dataServer[7].quantidade) + int(value);

  let compras = {
    "id":dataServer[1].id,
    "compra": quantidadeValor,
    "id_produto":dataServer[7].id_produto,
  };

  httpPost('/enviarCompras',compras,'json',(respostaServidor) => {
  });

  httpPost('/enviarDinheiro',updateDinheiro,'json',(respostaServidor1) => {
  })
  popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Bought Panike");
  popup1.draw_Card_Popup_Inventario();
  setTimeout(() => {
    scene=12;
    loop();
  }, 3000);
}
}

function getValues_7(){
  let value = inputs[7].getValue();

  let newDinheiro = dataServer[1].dinheiro_inicial - (value * dataServer[8].preco);

  if( newDinheiro <= 0){
    popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Not enough money");
    popup1.draw_Card_Popup_Inventario();
    setTimeout(() => {
      scene=12;
      loop();
    }, 3000);
  } else {
  let updateDinheiro = {
    "id": dataServer[1].id,
    "dinheiro_atual":newDinheiro,
  }

  let quantidadeValor = int(dataServer[8].quantidade) + int(value);

  let compras = {
    "id":dataServer[1].id,
    "compra": quantidadeValor,
    "id_produto":dataServer[8].id_produto,
  };

  httpPost('/enviarCompras',compras,'json',(respostaServidor) => {
  });

  httpPost('/enviarDinheiro',updateDinheiro,'json',(respostaServidor1) => {
  })
  popup1 = new Card_Popup_Inventario(width*0.5,height*0.5,"Bought CupCake");
  popup1.draw_Card_Popup_Inventario();
  setTimeout(() => {
    scene=12;
    loop();
  }, 3000);
}
}

function getValuesMilkRecipe() {
  //buscar valores dos inputs
  milk = InputCoffee[0].getValue();
  coffee = InputCoffee[1].getValue();
  sugar = InputCoffee[2].getValue();

  //verificação dos inputs
  let arraynumeros = [1,2,3,4,5,6,7,8,9,0];
  let arrayvariaveis = [int(milk),int(coffee),int(sugar)];

  let todosPresentes = arrayvariaveis.every(valor => arraynumeros.includes(valor));

    if (todosPresentes == false) {
      let recipe = new CoffeeRecipeWarning(width*0.5,height*0.5,"You cannot input letters or symbols or empty spaces!");
      recipe.draw_Card_CoffeeRecipeWarning();
      setTimeout(() => {
        InputCoffee = [];
        scene=9;
        loop();
      }, 2000);
    }

    if(milk>5){
      let recipe = new CoffeeRecipeWarning(width*0.5,height*0.5,"The quantity of milk must be less than 5.");
      recipe.draw_Card_CoffeeRecipeWarning();
      setTimeout(() => {
        InputCoffee = [];
        scene=9;
        loop();
      }, 2000);
    } else if(coffee>5){
      let recipe = new CoffeeRecipeWarning(width*0.5,height*0.5,"The quantity of coffee must be less than 5.");
      recipe.draw_Card_CoffeeRecipeWarning();
      setTimeout(() => {
        InputCoffee = [];
        scene=9;
        loop();
      }, 2000);
    } else if(sugar>5){
      let recipe = new CoffeeRecipeWarning(width*0.5,height*0.5,"The quantity of sugar must be less than 5.");
      recipe.draw_Card_CoffeeRecipeWarning();
      setTimeout(() => {
        InputCoffee = [];
        scene=9;
        loop();
      }, 2000);
    }

    if(milk<0){
      let recipe = new CoffeeRecipeWarning(width*0.5,height*0.9,"The quantity of milk must be a positive value.");
      recipe.draw_Card_CoffeeRecipeWarning();
      setTimeout(() => {
        InputCoffee = [];
        scene=9;
        loop();
      }, 2000);
    } else if(coffee<0){
      let recipe = new CoffeeRecipeWarning(width*0.5,height*0.5,"The quantity of coffee must be a positive value.");
      recipe.draw_Card_CoffeeRecipeWarning();
      setTimeout(() => {
        InputCoffee = [];
        scene=9;
        loop();
      }, 2000);
    } else if(sugar<0){
      let recipe = new CoffeeRecipeWarning(width*0.5,height*0.5,"The quantity of sugar must be a positive value.");
      recipe.draw_Card_CoffeeRecipeWarning();
      setTimeout(() => {
        InputCoffee = []; 
        scene=9;
        loop();
      }, 2000);
    } else if(int(milk)+int(coffee)+int(sugar) == 5){
        scene = 13;
        loop();
    } else if(int(milk) + int(coffee) + int(sugar) > 5){
      let recipe = new CoffeeRecipeWarning(width*0.5,height*0.5,"A coffee must be at most 5 units!");
      recipe.draw_Card_CoffeeRecipeWarning();
      setTimeout(() => {
        InputCoffee = []; 
        scene=9;
        loop();
      }, 2000);
    } else if(int(milk)+int(coffee)+int(sugar) > 5){
      let recipe = new CoffeeRecipeWarning(width*0.5,height*0.5,"A coffee must be at most 5 units!");
      recipe.draw_Card_CoffeeRecipeWarning();
      setTimeout(() => {
        InputCoffee = []; 
        scene=9;
        loop();
      }, 2000);
    }
}

function enviarNovasVariaveisMilk() {
 
  let variavelMilk = {
    "id":dataRecipe[1].id_player,
    "id_produto":dataRecipe[2].id_produto,
    "quantidade_produto_atual":milk,
  };

  httpPost('/enviarReceita',variavelMilk,'json',(respostaServidor) => {
  });
}

function enviarNovasVariaveisCoffee() {
 
  let variavelCoffee = {
    "id":dataRecipe[1].id_player,
    "id_produto":dataRecipe[3].id_produto,
    "quantidade_produto_atual":coffee,
  };

  httpPost('/enviarReceita',variavelCoffee,'json',(respostaServidor) => {
  });
}

function enviarNovasVariaveisSugar() {
 
  let variavelSugar = {
    "id":dataRecipe[1].id_player,
    "id_produto":dataRecipe[1].id_produto,
    "quantidade_produto_atual":sugar,
  };

  httpPost('/enviarReceita',variavelSugar,'json',(respostaServidor) => {
  });
}

//MousePressed on certain buttons changes scene
function mousePressed(){
    if(scene==0){
        if(btnPlay.on_Click(mouseX,mouseY)){
            scene=1;
            loop();
        } else if(btnLeaderboard.on_Click(mouseX,mouseY)){
            scene=2;
            loop();
        } else if(btnCredits.on_Click(mouseX,mouseY)){
            scene=3;
            loop();
        }

    } else if(scene==2){ //leaderboardScene~
      let x = width*0.85;
      let y = height*0.2;
      let altura = 60;
      let largura = 120;
        if(btnBack.on_Click(mouseX,mouseY)){
            scene=0;
            loop();
        }
        if(
          mouseX > x && mouseX < x + largura && mouseY > y && mouseY < y + altura
        ){
          scene=17;
          loop();
            textSize(27);
            text(dataLeaderboard[1].nome_cafe,width*0.55,height*0.3);
            text(dataLeaderboard[1].dinheiro_atual,width*0.55,height*0.35);
            text(dataLeaderboard[1].xp,width*0.55,height*0.4);
            text(dataLeaderboard[1].dia_utilizador,width*0.55,height*0.45);
          }

      if(
        mouseX > x && mouseX < x + largura && mouseY > y+100 && mouseY < y+100 + altura
      ){
        scene=17;
        loop();
        textSize(27);
        text(dataLeaderboard[2].nome_cafe,width*0.55,height*0.3);
        text(dataLeaderboard[2].dinheiro_atual,width*0.55,height*0.35);
        text(dataLeaderboard[2].xp,width*0.55,height*0.4);
        text(dataLeaderboard[2].dia_utilizador,width*0.55,height*0.45);
      }
    
      if(
        mouseX > x && mouseX < x + largura && mouseY > y+150 && mouseY < y+150 + altura
      ){
        scene=17;
        loop();
        textSize(27);
        text(dataLeaderboard[3].nome_cafe,width*0.55,height*0.3);
        text(dataLeaderboard[3].dinheiro_atual,width*0.55,height*0.35);
        text(dataLeaderboard[3].xp,width*0.55,height*0.4);
        text(dataLeaderboard[3].dia_utilizador,width*0.55,height*0.45);
      }

    } else if(scene==3){ //creditsScene
        if(btnBack.on_Click(mouseX,mouseY)){
            scene=0;
            loop();
        }

    } else if(scene==4){ //tutorialFirstScene
        if(btnNext.on_Click(mouseX,mouseY)){
            scene=5;
            loop();
        }

    } else if(scene==5){ //tutorialSecondScene
        if(btnNext.on_Click(mouseX,mouseY)){
            scene=6;
            loop();
        }
        if(btnBack.on_Click(mouseX,mouseY)){
          scene=4;
          loop();
      }

    } else if(scene==6){ //tutorialThirdScene
        if(btnNext.on_Click(mouseX,mouseY)){
            scene=7;
            loop();
        }
        if(btnBack.on_Click(mouseX,mouseY)){
          scene=5;
          loop();
      }

    } else if(scene==7){ //tutorialForthScene
        if(btnNext.on_Click(mouseX,mouseY)){
            scene=8;
            loop();
        }
        if(btnBack.on_Click(mouseX,mouseY)){
          scene=6;
          loop();
      }

    } else if(scene==8){ //inventoryScene
        if(btnNext.on_Click(mouseX,mouseY)){
            scene=9;
            loop();
        }
        if(btnInventory1.on_Click_Small(mouseX,mouseY)){
            scene = 8;
            loop();

        } if(arrProdutos.length >= 6 ){
            if(btnInventory2.on_Click_Small(mouseX,mouseY)){
            scene = 12;
            loop();
        }

        }
        if(btnBack.on_Click(mouseX,mouseY)){
          scene=7;
          loop();
        }
        if(btnBuy1.on_Click_Buy(mouseX,mouseY)){
          getValues();
          }
        if(btnBuy2.on_Click_Buy(mouseX,mouseY)){
          getValues_1();
        }
        if(btnBuy3.on_Click_Buy(mouseX,mouseY)){
          getValues_2();
        }
        if(btnBuy4.on_Click_Buy(mouseX,mouseY)){
          getValues_3();
        }

    } else if(scene==9){ //coffeeScene
      if(btnNext.on_Click(mouseX,mouseY)){
        getValuesMilkRecipe();
    }
      if(btnBack.on_Click(mouseX,mouseY)){
        scene = 9;
        loop();
      }
    } else if(scene==10){ //gameScene
        if(btnNext.on_Click(mouseX,mouseY)){
            scene=11;
            loop();
        }
      
    } else if(scene==11){ //dataScene
        if(btnNext.on_Click(mouseX,mouseY)){
            let profitLoss = dataServer[1].dinheiro_atual - dataServer[1].dinheiro_inicio_dia;
            if(profitLoss < 0){
              scene = 15;
              loop();
            } else if(profitLoss > 0){
              scene = 14;
              loop();
            } else if(profitLoss == 0){
              scene = 16;
              loop();
            }
            StopTimer();
        } 
    }  else if(scene == 12){ //inventoryScene2
      if(btnNext.on_Click(mouseX,mouseY)){
        scene=9;
        loop();
       } 
        if(btnInventory1.on_Click_Small(mouseX,mouseY)){
            scene=8;
            loop();
        } else if(btnInventory2.on_Click_Small(mouseX,mouseY)){
            scene=12;
            loop();
        }
        if(btnBuy5.on_Click_Buy(mouseX,mouseY)){
          getValues_4();
        }
        if(dataServer.length == 6){
        if(btnBuy6.on_Click_Buy(mouseX,mouseY)){
          getValues_5();
        }
       }if(dataServer.length == 7){
        if(btnBuy7.on_Click_Buy(mouseX,mouseY)){
          getValues_6();
        }}
        if(dataServer.length == 8){
        if(btnBuy8.on_Click_Buy(mouseX,mouseY)){
          getValues_7();
        }}
        if(btnBack.on_Click(mouseX,mouseY)){
          scene=12;
          loop();
        }
    } else if(scene == 13) {
      if(btnNext1.on_Click(mouseX,mouseY)){
        enviarNovasVariaveisMilk();
        enviarNovasVariaveisCoffee();
        enviarNovasVariaveisSugar();
        scene = 10;
        loop();
      }
      if(btnBack.on_Click(mouseX,mouseY)){
        InputCoffee = [];
        scene = 9;
        loop();
      }
    } else if(scene == 14){ 
      if(btnNext.on_Click(mouseX,mouseY)){
        scene = 8;
        i = 12;
        objetos = [];
        contadorObjetos = 0;
        frameCount = 0;
        InputCoffee = [];
        dataServer = [{}]
        loop();
      }
    } else if(scene == 15){ 
      if(btnNext.on_Click(mouseX,mouseY)){
        scene = 8;
        objetos = [];
        contadorObjetos = 0;
        frameCount = 0;
        InputCoffee = [];
        frameCount = 0;
        dataServer = [{}]
        loop();
      }
    } else if(scene == 16){ //Nao teve lucro, nem prejuizo
      if(btnStartNewDay.on_Click(mouseX,mouseY)){
        scene=8;
        objetos = [];
        contadorObjetos = 0;
        frameCount = 0;
        InputCoffee = [];
        frameCount = 0;
        dataServer = [{}]
        loop();
      }
  }else if(scene == 17){ //View Profile of Player in LeaderboardScene
    if(btnBack.on_Click(mouseX,mouseY)){
      scene=2;
      loop();
    }
}
}

function drawChart(centerX, centerY) {
  let inicio_dia = dataServer[1].dinheiro_inicio_dia;
  let fim_dia = dataServer[1].dinheiro_atual;

  let moneyData = [
    { time: "Begining of the day", amount: inicio_dia},
    { time: "End of the day", amount: fim_dia }
  ]; 

    push()

      rect(centerX/2,centerY/2,1100,600);
      textSize(30)
      fill('#000000');
      text('About today $', centerX,centerY*0.60);
      textSize(15)
    // Eixo X
    fill('#000000');
    strokeWeight(0.9);
    stroke("#000000");
    line(centerX - 300, centerY + 300, centerX + 300, centerY + 300);
    for (let i = 0; i < moneyData.length; i++) {
      let x = map(i, 0, moneyData.length - 1, centerX - 300, centerX + 300);
      line(x, centerY + 300, x, centerY + 290);
      text(moneyData[i].time, x, centerY + 320);
    }
  
    // Eixo Y
    line(centerX - 300, centerY - 100, centerX - 300, centerY + 300);
    for (let i = 0; i <= 3; i++) {
      let y = map(i * 50, 0, 150, centerY + 300, centerY - 100);
      line(centerX - 300, y, centerX - 290, y);
      text(i * 50, centerX - 330, y);
    }
  
    // Linha de gráfico
    beginShape();
    for (let i = 0; i < moneyData.length; i++) {
      let x = map(i, 0, moneyData.length - 1, centerX - 300, centerX + 300);
      let y = map(moneyData[i].amount, 0, 150, centerY + 300, centerY - 100);
      vertex(x, y);
      ellipse(x, y, 8, 8); // Ponto no gráfico
    }
    endShape();
    pop()
}

function generateInput(){
    for (let i = 0; i < numInputs; i++) {
      let input = new InputBox(width*0.58,height*0.40 + i * 100);
      inputs.push(input);
    }
}

function generateInput2(){
  for (let i = 0; i < 3; i++) {
    let input = new InputBox(width*0.29 + i * 375, height*0.53);
    InputCoffee.push(input);
  }
}

//FUNCTIONS FOR LEADERBOARD SCENE
function createLeaderboard(){
  for(let i=0;i<dataLeaderboard.length;i++){
    arrLeaderboard[i]=new Leaderboard(dataLeaderboard[i].id,dataLeaderboard[i].nome_cafe,dataLeaderboard[i].xp,dataLeaderboard[i].dia_utilizador,dataLeaderboard[i].dinheiro_atual);
  }
}

function createInterfaceLeaderboard(){
  popupDinheiro = new PopUp_Dinheiro();

  let initX=(popupDinheiro.x-popupDinheiro.sx/2)+5;
  let initY=(popupDinheiro.y-popupDinheiro.sy/2)+15;
 
  for(let i=0;i<arrLeaderboard.length;i++){
    arrCardsLeaderboard[i]=new Card_Leaderboard(initX,initY,arrLeaderboard[i]);   
    initY+=100;    
  }
 
}

function drawInterfaceLeaderboard(){
  push()
  for(let i=1;i<arrCardsLeaderboard.length;i++){
    arrCardsLeaderboard[i].draw_CardLeaderboard();
  }
  pop()
}

function createProducts(){
    for(let i=0;i<dataServer.length;i++){
     arrProdutos[i]=new Produto(dataServer[i].nome_produto,dataServer[i].preco,dataServer[i].quantidade);
   }
}
  
function createDinheiro(){
    for(let i=0;i<dataServer.length;i++){
     arrDinheiro[i]=new Dinheiro(dataServer[i].dinheiro_inicial,dataServer[i].dia_utilizador,dataServer[i].temperatura);
   }
}
  
function createTabela(){
    for(let i=0;i<dataServer.length;i++){
      arrTabela[i]=new Tabela(dataServer[i].dinheiro_inicio_dia,dataServer[i].dinheiro_atual);
    }
}
  
function createInterface(){
  
    let sx = width*0.63;
    let sy = height*0.55
   let initX=(popup.x-sx/2)+5;
   let initY=(popup.y-sy/2)+15;
  
   for(let i=0;i<arrProdutos.length;i++){
   arrCards[i]=new Card(initX,initY,arrProdutos[i]);
   initY+=100;  
   }
  
}

function createInterface_Inventario_Game(){
  
  let sx = width*0.63;
  let sy = height*0.55
 let initX=(popup.x-sx/2)+5;
 let initY=(popup.y-sy/2)+15;

 for(let i=0;i<arrProdutos.length;i++){
 arrCards[i]=new Card_Inventario_Game(initX,initY,arrProdutos[i]);
 initY+=30;  
 }

}
  
function createInterfaceDinheiro(){
  
    let initX=(popupDinheiro.x-popupDinheiro.sx/2)+5;
    let initY=(popupDinheiro.y-popupDinheiro.sy/2)+15;
   
    for(let i=0;i<arrDinheiro.length;i++){
    
    arrCardsDinheiro[i]=new Card_Dinheiro(initX,initY,arrDinheiro[i]);    
    }
   
}
  
function createInterfaceTabela(){
    let initX=(popupDinheiro.x-popupDinheiro.sx/2)+5;
    let initY=(popupDinheiro.y-popupDinheiro.sy/2)+15;
   
    for(let i=0;i<arrTabela.length;i++){
    
    arrCardsTabela[i]=new Card_Tabela(initX,initY,arrTabela[i]);    
    }
}
  
function drawInterface(){
    push()
    for(let i=1;i<5;i++){
      arrCards[i].draw_Card();
    }
    pop()
}

function createInterface2(){
  
    let sx = width*0.63;
    let sy = height*0.55
   let initX=(popup.x-sx/2)+5;
   let initY=(popup.y-sy/2)+15;
  
   for(let i=4;i<arrProdutos.length;i++){
   arrCards[i]=new Card(initX,initY,arrProdutos[i]);
   initY+=100;  
   }
  
}

function drawInterface2(){
     push()
     for(let i=5;i<arrCards.length;i++){
       arrCards[i].draw_Card();
     }
     pop()
}

function drawInterface_Inventario_Game(){
  push()
  for(let i=1;i<arrCards.length;i++){
    arrCards[i].draw_Card_Inventario_Game();
  }
  pop()
}
  
function drawInterfaceDinheiro(){
    push()
      arrCardsDinheiro[1].draw_Card_Dinheiro();
    pop()
}
  
function drawInterfaceTabela(){
    push()
      arrCardsTabela[1].draw_CardTabela();
    pop()
}
  
function createLeaderboard(){
    for(let i=0;i<dataLeaderboard.length;i++){
      arrLeaderboard[i]=new Leaderboard(dataLeaderboard[i].id,dataLeaderboard[i].nome_cafe,dataLeaderboard[i].xp,dataLeaderboard[i].dia_utilizador,dataLeaderboard[i].dinheiro_atual);
    }
}
  
function createInterfaceLeaderboard(){
    let initX=(popupDinheiro.x-popupDinheiro.sx/2)+5;
    let initY=(popupDinheiro.y-popupDinheiro.sy/2)+15;
   
    for(let i=0;i<arrLeaderboard.length;i++){
    
    arrCardsLeaderboard[i]=new Card_Leaderboard(initX,initY,arrLeaderboard[i]);   
    initY+=80;    
    }
   
}
  
function drawInterfaceLeaderboard(){
    push()
    for(let i=1;i<arrCardsLeaderboard.length;i++){
      arrCardsLeaderboard[i].draw_CardLeaderboard();
    }
    pop()
}


//RESPONSIVENESS
function windowResized() {
  setDimensions();
  resizeCanvas(canvasSize, canvasSize); 
}

function centerCanvas() {
  let s = document.body.style;
  s.display = "flex";
  s.overflow = "hidden";
  s.height = "100vh"; //100% da altura da janela
  s.alignItems = "center";
  s.justifyContent = "center";
}

function setDimensions() {
  fullScreen = isFullscreen();
  canvasSize = min(windowWidth, windowHeight);
  if (hasMaxSize) {
    canvasSize = min(referenceSize, canvasSize);
  }
  windowScale = map(canvasSize, 0, referenceSize, 0, 1, hasMaxSize);
}

function isFullscreen() {
  if (
    document.fullscreenElement ||
    window.screen.height - window.innerHeight <= 3 ||
    isEdgeFullscreen() ||
    isSafariFullscreen()
  ) {
    return true;
  }
  return false;
}

function isSafariFullscreen() {
  if (document.webkitIsFullScreen) {
    return true;
  }
  return false;
}

function isEdgeFullscreen() {
  if (isUserAgent("Edg") && window.screen.height - window.innerHeight <= 235) {
    return true;
  }
  return false;
}

function isUserAgent(name) {
  if (window.navigator.userAgent.indexOf(name) > -1) {
    return true;
  }
  return false;
}

