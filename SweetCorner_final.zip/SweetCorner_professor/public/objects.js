class PopUp {
  
  constructor(){
    this.x=width/2;
    this.y=height/1.8;
    this.sx=width*0.23;
    this.sy=height*0.3;
  }
  
  draw_PopUp(){
    push();
    pop();
  }
}

class PopUp_Dinheiro {

  constructor(){
    this.x=width/11;
    this.y=height/15;
    this.sx=width*0.1;
    this.sy=height*0.05;
  }
  
  draw_PopUpDinheiro(){
    push();
    rectMode(CENTER)
    fill("#ffffff");
    rect(this.x,this.y,this.sx,this.sy,100);
    rect(width*0.87,this.y,width*0.15,this.sy,100)
    pop();
  }
}

class PopUp_Login {

  constructor(){
    this.x=width/2;
    this.y=height/2.5;
    this.sx=width*0.4;
    this.sy=height*0.6;
  }
  
  draw_PopUp_Login(){
    push();
    rectMode(CENTER)
    fill("#ffffff");
    rect(this.x,this.y,this.sx,this.sy,15);
    pop();
  }
}

class PopUp_Tabela{
  constructor(){
    this.x=width/11;
    this.y=height/15;
    this.sx=width*0.1;
    this.sy=height*0.05;
  }
  
  draw_PopUpTabela(){
    push();
    rectMode(CENTER)
    fill("#ffffff");
    rect(this.x,this.y,this.sx,this.sy,100);
    rect(width*0.885,this.y,width*0.15,this.sy,100);
    pop();
  }
}

class PopUp_ConfirmacaoLogin{
  constructor(){
    this.x=width/2;
    this.y=height/1.8;
    this.sx=width*0.23;
    this.sy=height*0.3;
  }
  
  draw_PopUpConfirmacaoLogin(){
    push();
    pop();
  }
}

class Produto{

  constructor(nome_produto,preco,quantidade){
  this.nome_produto=nome_produto;
  this.preco=preco;
  this.quantidade=quantidade;
  }
}

class Dinheiro{

  constructor(dinheiro_inicial,dia,temperatura){
  this.dinheiro_inicial=dinheiro_inicial;
  this.dia=dia;
  this.temperatura=temperatura;
  }
}

class Card{
  constructor(x,y,produto){
  this.x=x+width/7;
  this.y=y+height/8;
  this.produto=produto;
  }

draw_Card(){
  push();
  fill("#ffffff")
  rect(this.x-width/26,this.y-height*0.17,width/2,height/11,30);
  fill(0);
  textSize(15)
  text("Quantity required:",this.x+width/4.2,this.y-height*0.15); //"", width, height
  textSize(20);
  text(this.produto.nome_produto,this.x,this.y-height*0.120);
  text(this.produto.preco+"$",this.x+width/6,this.y-height*0.120);
  text(this.produto.quantidade,this.x+width/2.8,this.y-height*0.120);
  pop();
}
}

class Card_Inventario_Game{
constructor(x,y,produto){
this.x=width*0.02;
this.y=y+height*0.42;
this.produto=produto;
}

draw_Card_Inventario_Game(){
  push();
  fill(0);
  textSize(15);
  text(this.produto.nome_produto,this.x,this.y);
  text(this.produto.quantidade,this.x+width*0.145,this.y);
  pop();
}
}

class Card_Dinheiro{

  constructor(x,y,dinheiro){
  this.x=x;
  this.y=y;
  this.dinheiro=dinheiro;
  }

draw_Card_Dinheiro(){

  push();
  fill(0)
  textSize(30);
  text(this.dinheiro.dinheiro_inicial + "$",width*0.083,height/13)
  text("Day " + this.dinheiro.dia,width*0.82,height/13)
  text("|",width*0.89,height/13);
  text(this.dinheiro.temperatura + "º",width*0.915,height/13)
  pop();

}
  
}

class Tabela{
  constructor(dinheiro_inicio_dia,dinheiro_atual){
    this.dinheiro_inicio_dia=dinheiro_inicio_dia;
    this.dinheiro_atual=dinheiro_atual;
  }  
}

class Card_Tabela{
  constructor(x,y,tabela){
    this.x=x;
    this.y=y;
    this.tabela=tabela;
  }  

  draw_CardTabela(){
    push();
      fill(255);
      textSize(30);
      rect(this.x+200,this.y+150,1500,600,20);
      fill(0)
      text("Dinheiro do Inicio do dia => " + this.tabela.dinheiro_inicio_dia,width*0.3,height/3);
      text("Dinheiro do Final do dia => " + this.tabela.dinheiro_atual, width*0.3,height/2);
    pop();
  }
}

class Leaderboard{
constructor(id,nome_cafe,xp,dia_utilizador,dinheiro_atual){
  this.id=id;
  this.nome_cafe=nome_cafe;
  this.xp=xp;
  this.dia_utilizador=dia_utilizador;
  this.dinheiro_atual=dinheiro_atual;
}
}

class Card_Leaderboard{
constructor(x,y,leaderboard){
  this.x=x+width/7;
  this.y=y+height/8;
  this.leaderboard=leaderboard;
}  

draw_CardLeaderboard(){
  push();
    fill(255);
    textSize(25);
    fill(230)
    rect(this.x-width/26,this.y-height*0.085,width*0.68,height*0.08,30);
    fill(0);
    text(this.leaderboard.id,this.x,this.y-height*0.035);
    text(this.leaderboard.nome_cafe,this.x+width/6,this.y-height*0.035);
    text(this.leaderboard.xp,this.x+width/2.8,this.y-height*0.035);
    text(this.leaderboard.dia_utilizador,this.x+width/2.1,this.y-height*0.035);
    text(this.leaderboard.dinheiro_atual,this.x+width/1.7,this.y-height*0.035);
  pop();
}
}

//recebe valor na scene do Coffee Recipe
class InputBox {
  constructor(x, y) {
    this.input = createInput();
    this.input.position(x, y);
    this.input.style('font-size','30px');
    this.input.size(70,40);

  }

  getValue() {
    return this.input.value();
  }
}

//gerar personagens
function criarObjeto() {

  // Cria um novo objeto e o adiciona ao array de objetos
  let novoObjeto = new Objeto();
  objetos.push(novoObjeto);
}

class Objeto {
  constructor() {
    this.x= 0;
    this.imgPersonagem=random(imgsPersonagens);
    this.imgBalao = imgBalao; //gera aleatoriamente umas das imagens dos clientes
    this.pedido = random(arrayPedidos);
    this.y = 355;
    this.tamanhoX = 250; //width
    this.tamanhoY = 575; //height
    this.cor = color(random(255), random(255), random(255));
    this.velocidade = 2; // Velocidade do movimento
    this.estado = 'movendo'; // Estado inicial
    this.tempoEspera = 180; // 60 frames por segundo * 3 segundos
    
  }

  atualizar() {
    if (this.estado == 'movendo') {
      // Atualiza a posição do objeto para movê-lo da esquerda para a direita
      this.x += this.velocidade;


      // Verifica se atingiu o centro da tela
      if (this.x >= width / 2) {
        this.estado = 'esperando';
      }
    } else if (this.estado == 'esperando') {
      // Aguarda no centro da tela
      this.tempoEspera--;

      // Verifica se o tempo de espera acabou
      if (this.tempoEspera <= 0) {
        this.estado = 'continuando';
      }
    } else if (this.estado == 'continuando') {
      // Continua movendo até o final da tela
      this.x += this.velocidade;
    }
  }

  pedidos() {
    if(this.estado == 'esperando'){
      image(this.imgBalao,this.x+width*0.07,this.y-height*0.06,200,100);
      text(this.pedido,this.x+width*0.11,this.y-height*0.018);
      if(arrayPedidos.length == 3){
        if(this.pedido == "Coffee"){
          if(this.tempoEspera == 100){
              let quantidadecopocafe = produto.quantidade - 1;
              let quantidadeleite = produto.quantidade1 - int(milk);
              let quantidadeacucar = produto.quantidade2 - int(coffee);
              let quantidadecafe = produto.quantidade3 - int(sugar);

              let compras = {
                "id":dataServer[1].id,
                "id_produto":1,
                "quantidade":quantidadecopocafe,
              }
              httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
                getProdutos();
              });

              let compras2 = {
                "id":dataServer[1].id,
                "id_produto":2,
                "quantidade":quantidadeleite,
              }
              httpPost('/enviarNovasInformacoes',compras2,'json',(respostaServidor) => {
                getProdutos1();
              });

              let compras3 = {
                "id":dataServer[1].id,
                "id_produto":3,
                "quantidade":quantidadeacucar,
              }
              httpPost('/enviarNovasInformacoes',compras3,'json',(respostaServidor) => {
                getProdutos2();
              });

              let compras4 = {
                "id":dataServer[1].id,
                "id_produto":4,
                "quantidade":quantidadecafe,
              }
              httpPost('/enviarNovasInformacoes',compras4,'json',(respostaServidor) => {
                getProdutos3();
              });

              let novoDinheiro = {
                "id":dataServer[1].id,
                "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
              }

              httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
              });
          }
        } 

        if(this.pedido == "Milk"){
          if(this.tempoEspera == 100){
            let quantidadecopocafe = produto.quantidade - 1;
            let quantidadeleite = produto.quantidade1 - 1;

            let compras = {
              "id":dataServer[1].id,
              "id_produto":1,
              "quantidade":quantidadecopocafe,
            }
            httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
              getProdutos();
            });

            let compras2 = {
              "id":dataServer[1].id,
              "id_produto":2,
              "quantidade":quantidadeleite,
            }
            httpPost('/enviarNovasInformacoes',compras2,'json',(respostaServidor) => {
              getProdutos1();
            });
            let novoDinheiro = {
              "id":dataServer[1].id,
              "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
            }

            httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
            });
          }
        }

        if(this.pedido == "Croissant"){
          if(this.tempoEspera == 100){
            let quantidadecroissant = produto.quantidade4 - 1;

            let compras = {
              "id":dataServer[1].id,
              "id_produto":5,
              "quantidade":quantidadecroissant,
            }
            httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
              getProdutos4();
            });
            let novoDinheiro = {
              "id":dataServer[1].id,
              "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
            }

            httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
            });
          }
        }
    }
    if(arrayPedidos.length == 4){
      if(this.pedido == "Coffee"){
        if(this.tempoEspera == 100){
            let quantidadecopocafe = produto.quantidade - 1;
            let quantidadeleite = produto.quantidade1 - int(milk);
            let quantidadeacucar = produto.quantidade2 - int(coffee);
            let quantidadecafe = produto.quantidade3 - int(sugar);

            let compras = {
              "id":dataServer[1].id,
              "id_produto":1,
              "quantidade":quantidadecopocafe,
            }
            httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
              getProdutos();
            });

            let compras2 = {
              "id":dataServer[1].id,
              "id_produto":2,
              "quantidade":quantidadeleite,
            }
            httpPost('/enviarNovasInformacoes',compras2,'json',(respostaServidor) => {
              getProdutos1();
            });

            let compras3 = {
              "id":dataServer[1].id,
              "id_produto":3,
              "quantidade":quantidadeacucar,
            }
            httpPost('/enviarNovasInformacoes',compras3,'json',(respostaServidor) => {
              getProdutos2();
            });

            let compras4 = {
              "id":dataServer[1].id,
              "id_produto":4,
              "quantidade":quantidadecafe,
            }
            httpPost('/enviarNovasInformacoes',compras4,'json',(respostaServidor) => {
              getProdutos3();
            });
            let novoDinheiro = {
              "id":dataServer[1].id,
              "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
            }

            httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
            });
        }
      } 

      if(this.pedido == "Milk"){
        if(this.tempoEspera == 100){
          let quantidadecopocafe = produto.quantidade - 1;
          let quantidadeleite = produto.quantidade1 - 1;

          let compras = {
            "id":dataServer[1].id,
            "id_produto":1,
            "quantidade":quantidadecopocafe,
          }
          httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
            getProdutos();
          });

          let compras2 = {
            "id":dataServer[1].id,
            "id_produto":2,
            "quantidade":quantidadeleite,
          }
          httpPost('/enviarNovasInformacoes',compras2,'json',(respostaServidor) => {
            getProdutos1();
          });
          let novoDinheiro = {
            "id":dataServer[1].id,
            "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
          }

          httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
          });
        }
      }

      if(this.pedido == "Croissant"){
        if(this.tempoEspera == 100){
          let quantidadecroissant = produto.quantidade4 - 1;

          let compras = {
            "id":dataServer[1].id,
            "id_produto":5,
            "quantidade":quantidadecroissant,
          }
          httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
            getProdutos4();
          });
          let novoDinheiro = {
            "id":dataServer[1].id,
            "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
          }

          httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
          });
        }
      }

      if(this.pedido == "Muffin"){
        if(this.tempoEspera == 100){
          let quantidademuffin = produto.quantidade5 - 1;

          let compras = {
            "id":dataServer[1].id,
            "id_produto":6,
            "quantidade":quantidademuffin,
          }
          httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
            getProdutos5();
          });
          let novoDinheiro = {
            "id":dataServer[1].id,
            "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
          }

          httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
          });
        }
      }
    }
      if(arrayPedidos.length == 5){
        if(this.pedido == "Coffee"){
          if(this.tempoEspera == 100){
              let quantidadecopocafe = produto.quantidade - 1;
              let quantidadeleite = produto.quantidade1 - int(milk);
              let quantidadeacucar = produto.quantidade2 - int(coffee);
              let quantidadecafe = produto.quantidade3 - int(sugar);

              let compras = {
                "id":dataServer[1].id,
                "id_produto":1,
                "quantidade":quantidadecopocafe,
              }
              httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
                getProdutos();
              });

              let compras2 = {
                "id":dataServer[1].id,
                "id_produto":2,
                "quantidade":quantidadeleite,
              }
              httpPost('/enviarNovasInformacoes',compras2,'json',(respostaServidor) => {
                getProdutos1();
              });

              let compras3 = {
                "id":dataServer[1].id,
                "id_produto":3,
                "quantidade":quantidadeacucar,
              }
              httpPost('/enviarNovasInformacoes',compras3,'json',(respostaServidor) => {
                getProdutos2();
              });

              let compras4 = {
                "id":dataServer[1].id,
                "id_produto":4,
                "quantidade":quantidadecafe,
              }
              httpPost('/enviarNovasInformacoes',compras4,'json',(respostaServidor) => {
                getProdutos3();
              });
              let novoDinheiro = {
                "id":dataServer[1].id,
                "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
              }

              httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
              });
          }
        } 

        if(this.pedido == "Milk"){
          if(this.tempoEspera == 100){
            let quantidadecopocafe = produto.quantidade - 1;
            let quantidadeleite = produto.quantidade1 - 1;

            let compras = {
              "id":dataServer[1].id,
              "id_produto":1,
              "quantidade":quantidadecopocafe,
            }
            httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
              getProdutos();
            });

            let compras2 = {
              "id":dataServer[1].id,
              "id_produto":2,
              "quantidade":quantidadeleite,
            }
            httpPost('/enviarNovasInformacoes',compras2,'json',(respostaServidor) => {
              getProdutos1();
            });
            let novoDinheiro = {
              "id":dataServer[1].id,
              "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
            }

            httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
            });
          }
        }

        if(this.pedido == "Croissant"){
          if(this.tempoEspera == 100){
            let quantidadecroissant = produto.quantidade4 - 1;

            let compras = {
              "id":dataServer[1].id,
              "id_produto":5,
              "quantidade":quantidadecroissant,
            }
            httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
              getProdutos4();
            });
            let novoDinheiro = {
              "id":dataServer[1].id,
              "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
            }

            httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
            });
          }
        }

        if(this.pedido == "Muffin"){
          if(this.tempoEspera == 100){
            let quantidademuffin = produto.quantidade5 - 1;

            let compras = {
              "id":dataServer[1].id,
              "id_produto":6,
              "quantidade":quantidademuffin,
            }
            httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
              getProdutos5();
            });
            let novoDinheiro = {
              "id":dataServer[1].id,
              "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
            }

            httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
            });
          }
        }

        if(this.pedido == "Panike"){
          if(this.tempoEspera == 100){
            let quantidadepanike = produto.quantidade6 - 1;

            let compras = {
              "id":dataServer[1].id,
              "id_produto":7,
              "quantidade":quantidadepanike,
            }
            httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
              getProdutos6();
            });
            let novoDinheiro = {
              "id":dataServer[1].id,
              "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
            }

            httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
            });
          }
        }
    }

    if(arrayPedidos.length == 6){
      if(this.pedido == "Coffee"){
        if(this.tempoEspera == 100){
            let quantidadecopocafe = produto.quantidade - 1;
            let quantidadeleite = produto.quantidade1 - int(milk);
            let quantidadeacucar = produto.quantidade2 - int(coffee);
            let quantidadecafe = produto.quantidade3 - int(sugar);

            let compras = {
              "id":dataServer[1].id,
              "id_produto":1,
              "quantidade":quantidadecopocafe,
            }
            httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
              getProdutos();
            });

            let compras2 = {
              "id":dataServer[1].id,
              "id_produto":2,
              "quantidade":quantidadeleite,
            }
            httpPost('/enviarNovasInformacoes',compras2,'json',(respostaServidor) => {
              getProdutos1();
            });

            let compras3 = {
              "id":dataServer[1].id,
              "id_produto":3,
              "quantidade":quantidadeacucar,
            }
            httpPost('/enviarNovasInformacoes',compras3,'json',(respostaServidor) => {
              getProdutos2();
            });

            let compras4 = {
              "id":dataServer[1].id,
              "id_produto":4,
              "quantidade":quantidadecafe,
            }
            httpPost('/enviarNovasInformacoes',compras4,'json',(respostaServidor) => {
              getProdutos3();
            });
            let novoDinheiro = {
              "id":dataServer[1].id,
              "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
            }

            httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
            });
        }
      }  

      if(this.pedido == "Milk"){
        if(this.tempoEspera == 100){
          let quantidadecopocafe = produto.quantidade - 1;
          let quantidadeleite = produto.quantidade1 - 1;

          let compras = {
            "id":dataServer[1].id,
            "id_produto":1,
            "quantidade":quantidadecopocafe,
          }
          httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
            getProdutos();
          });

          let compras2 = {
            "id":dataServer[1].id,
            "id_produto":2,
            "quantidade":quantidadeleite,
          }
          httpPost('/enviarNovasInformacoes',compras2,'json',(respostaServidor) => {
            getProdutos1();
          });
          let novoDinheiro = {
            "id":dataServer[1].id,
            "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
          }

          httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
          });
        }
      }

      if(this.pedido == "Croissant"){
        if(this.tempoEspera == 100){
          let quantidadecroissant = produto.quantidade4 - 1;

          let compras = {
            "id":dataServer[1].id,
            "id_produto":5,
            "quantidade":quantidadecroissant,
          }
          httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
            getProdutos4();
          });
          let novoDinheiro = {
            "id":dataServer[1].id,
            "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
          }

          httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
          });
        }
      }

      if(this.pedido == "Muffin"){
        if(this.tempoEspera == 100){
          let quantidademuffin = produto.quantidade5 - 1;

          let compras = {
            "id":dataServer[1].id,
            "id_produto":6,
            "quantidade":quantidademuffin,
          }
          httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
            getProdutos5();
          });
          let novoDinheiro = {
            "id":dataServer[1].id,
            "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
          }

          httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
          });
        }
      }

      if(this.pedido == "Panike"){
        if(this.tempoEspera == 100){
            let quantidadepanike = produto.quantidade6 - 1;

            let compras = {
              "id":dataServer[1].id,
              "id_produto":7,
              "quantidade":quantidadepanike,
            }
            httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
              getProdutos6();
            });
            let novoDinheiro = {
              "id":dataServer[1].id,
              "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
            }

            httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
            });
          }
      }

      if(this.pedido == "Cupcake"){
        if(this.tempoEspera == 100){
            let quantidadecupcake = produto.quantidade7 - 1;

            let compras = {
              "id":dataServer[1].id,
              "id_produto":8,
              "quantidade":quantidadecupcake,
            }
            httpPost('/enviarNovasInformacoes',compras,'json',(respostaServidor) => {
              getProdutos7();
            });
            let novoDinheiro = {
              "id":dataServer[1].id,
              "dinheiro":int(dataServer[1].dinheiro_atual) + 8,
            }

            httpPost('/enviarNovasInformacoesDinheiro',novoDinheiro,'json',(respostaServidor) => {
            });
          }
      }
  }
  }
  }

  
  exibir() {
    image(this.imgPersonagem,this.x,this.y,this.tamanhoX,this.tamanhoY);

  }
  
  
  chegouAoFim() {
    // Retorna true se o objeto atingiu o final da tela
    return this.x > width;
  }
}

class Card_Popup_Inventario{
constructor(x,y,cont){
  this.x=x;
  this.y=y;
  this.cont = cont;
}  

draw_Card_Popup_Inventario(){
  push();
    fill("#FFFFFF");
    rectMode(CENTER);
    rect(width*0.5,height*0.15,width*0.3,height*0.1,100);
    fill("#000000");
    text(this.cont,width*0.42,height*0.16);
  pop();
}
}

class Button{

constructor(cont,centroX,centroY){

  this.centroX=centroX;
  this.centroY=centroY;
  this.largura=160;
  this.altura=50;
  this.corBt="#f5dd67";
  this.corBordaBt = "#ebeae6";
  this.tamTexto=20;
  this.corTexto=0;
  this.conteudo=cont;
  
}

draw_Button(){

push();
rectMode(CENTER);
fill(this.corBt);
stroke(this.corBordaBt);
rect(this.centroX,this.centroY, this.largura, this.altura, 20);
textAlign(CENTER, CENTER);
textSize(this.tamTexto);
fill(this.corTexto);
text(this.conteudo, this.centroX,this.centroY);
pop();
}

on_Click(x,y){

  if (
  x > this.centroX - this.largura / 2 &&
  x < this.centroX + this.largura / 2 &&
  y > this.centroY - this.altura / 2 &&
  y < this.centroY + this.altura / 2
) {
  return true;
} else {
  return false;
}
}

on_Hover(x,y){

  if (
  x > this.centroX - this.largura / 2 &&
  x < this.centroX + this.largura / 2 &&
  y > this.centroY - this.altura / 2 &&
  y < this.centroY + this.altura / 2
) {
  return true;
} else {
  return false;
}
}


}

class ButtonSmallInventory{

constructor(cont,centroX,centroY){

  this.centroX=centroX;
  this.centroY=centroY;
  this.largura=30;
  this.altura=40;
  this.corBt="#f5dd67";
  this.corBordaBt = "#ebeae6";
  this.tamTexto=20;
  this.corTexto=0;
  this.conteudo=cont;
  
}

draw_Button_Small(){

push();
rectMode(CENTER);
fill(this.corBt);
stroke(this.corBordaBt);
rect(this.centroX,this.centroY, this.largura, this.altura);
textAlign(CENTER, CENTER);
textSize(this.tamTexto);
fill(this.corTexto);
text(this.conteudo, this.centroX,this.centroY);
pop();
}

on_Click_Small(x,y){

  if (
  x > this.centroX - this.largura / 2 &&
  x < this.centroX + this.largura / 2 &&
  y > this.centroY - this.altura / 2 &&
  y < this.centroY + this.altura / 2
) {
  return true;
} else {
  return false;
}
}

on_Hover_Small(x,y){

  if (
  x > this.centroX - this.largura / 2 &&
  x < this.centroX + this.largura / 2 &&
  y > this.centroY - this.altura / 2 &&
  y < this.centroY + this.altura / 2
) {
  return true;
} else {
  return false;
}
}


}

class ButtonPlusLess{

constructor(cont,centroX,centroY){

  this.centroX=centroX;
  this.centroY=centroY;
  this.largura=40;
  this.altura=30;
  this.corBt="#f5dd67";
  this.corBordaBt = "#ebeae6";
  this.tamTexto=20;
  this.corTexto=0;
  this.conteudo=cont;
  
}

draw_ButtonPlusLess(){
  push();
  rectMode(CENTER);
  fill(this.corBt);
  stroke(this.corBordaBt);
  rect(this.centroX,this.centroY, this.largura, this.altura, 20);
  textAlign(CENTER, CENTER);
  textSize(this.tamTexto);
  fill(this.corTexto);
  text(this.conteudo, this.centroX,this.centroY);
  pop();
}

on_ClickPlusLess(x,y){

  if (
  x > this.centroX - this.largura / 2 &&
  x < this.centroX + this.largura / 2 &&
  y > this.centroY - this.altura / 2 &&
  y < this.centroY + this.altura / 2
) {
  return true;
} else {
  return false;
}
}

on_HoverPlusLess(x,y){

  if (
  x > this.centroX - this.largura / 2 &&
  x < this.centroX + this.largura / 2 &&
  y > this.centroY - this.altura / 2 &&
  y < this.centroY + this.altura / 2
) {
  return true;
} else {
  return false;
}
}
}

class CoffeeRecipeWarning {
constructor(x,y,cont){
  this.x=x;
  this.y=y;
  this.cont = cont;
}  

draw_Card_CoffeeRecipeWarning(){
  push();
    fill("#FFFFFF");
    rectMode(CENTER);
    rect(this.x,this.y - height*0.35,width*0.3,height*0.1,100);
    fill("#000000");
    text(this.cont,this.x-width*0.08,this.y - height*0.34);
  pop();
}
}

class ButtonBuy{

constructor(cont,centroX,centroY){

  this.centroX=centroX;
  this.centroY=centroY;
  this.largura=70;
  this.altura=45;
  this.corBt="#f5dd67";
  this.corBordaBt = "#ebeae6";
  this.tamTexto=20;
  this.corTexto=0;
  this.conteudo=cont;
  
}

draw_Button_Buy(){

push();
rectMode(CENTER);
fill(this.corBt);
stroke(this.corBordaBt);
rect(this.centroX,this.centroY, this.largura, this.altura, 20);
textAlign(CENTER, CENTER);
textSize(this.tamTexto);
fill(this.corTexto);
text(this.conteudo, this.centroX,this.centroY);
pop();
}

on_Click_Buy(x,y){

  if (
  x > this.centroX - this.largura / 2 &&
  x < this.centroX + this.largura / 2 &&
  y > this.centroY - this.altura / 2 &&
  y < this.centroY + this.altura / 2
) {
  return true;
} else {
  return false;
}
}

on_Hover_Buy(x,y){

  if (
  x > this.centroX - this.largura / 2 &&
  x < this.centroX + this.largura / 2 &&
  y > this.centroY - this.altura / 2 &&
  y < this.centroY + this.altura / 2
) {
  return true;
} else {
  return false;
}
}
}

class Card_Popup_ProfitLossScenes{
constructor(x,y,titulo,cont){
  this.x=x;
  this.y=y;
  this.titulo = titulo;
  this.cont = cont;
}  

draw_Card_Popup_ProfitLossScenes(){
  push();
    fill("#FFFFFF");
    rectMode(CENTER);
    rect(width*0.5,height*0.4,width*0.3,height*0.3,100);
    fill("#000000");
    text(this.titulo,width*0.43,height*0.33)
    text(this.cont,width*0.39,height*0.37);

  pop();
}
}


class Card_Popup_ViewOtherPlayerProfile{
constructor(x,y,titulo,cont){
  this.x=x;
  this.y=y;
  this.titulo = titulo;
  this.cont = cont;
}  

draw_Card_Popup_ViewOtherPlayerProfile(){
  push();
    fill("#FFFFFF");
    rectMode(CENTER);
    rect(width*0.5,height*0.4,width*0.4,height*0.5,100);
    fill("#000000");
    textSize(30);
    text(this.titulo,width*0.43,height*0.33)
    text(this.cont,width*0.39,height*0.37);

  pop();
}
}