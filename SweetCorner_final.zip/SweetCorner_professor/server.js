const express = require('express')
var bodyParser = require('body-parser')
const app = express()
const port = 3000 

const mysql = require('mysql')

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())

app.use(express.static('public'))

//CODE FOR CONNECTION TO DATABASE
const dbase = mysql.createConnection({
    host:"localhost",
    port:"3306", 
    user:"root", 
    password:"",
    database:"SweetCorner", 
});
// fim database connection

dbase.connect(function(err){
    if(err)throw err;
    console.log("Database Connected!");
    });

app.post('/login', (req,res)=>{
    let nome_cafe = req.body.nome_cafe;
    let email = req.body.email;
    let password = req.body.password;

    let sql = "SELECT * FROM utilizadores WHERE nome_cafe='"+nome_cafe+"'AND email='"+email+"'AND password ='"+password+"';"

    dbase.query(sql,(err, result)=>{
        if(err) throw err;
            res.send(result);
    });
});

app.get('/getLeaderboard/:id',(req,res)=>{

  let sql = "SELECT * FROM utilizadores";

    dbase.query(sql, (err,result)=>{
       if(err) throw err; 

        res.send(result);

    });

}); 

app.post('/register',(req,res)=>{

    let nome_cafe = req.body.nome_cafe;
    let email = req.body.email;
    let password = req.body.password;
     
    let sql = "SELECT * FROM utilizadores WHERE nome_cafe='"+nome_cafe+"'AND email='"+email+"';"
    //nao pode haver dois utilizadores com o mesmo nome de cafe e mesmo email

    dbase.query(sql, (err,result)=>{
    if(err) throw err; 
  
      if(result.length>0){
      
        res.send({"ack":0})
      
      }else{
  
        let sql = "INSERT INTO utilizadores (`nome_cafe`,`email`,`password`,`xp`,`dia_utilizador`,`dinheiro_inicial`,`dinheiro_inicio_dia`) VALUES ('"+nome_cafe+"','"+email+"','"+password+"','"+0+"','"+1+"','"+30+"','"+30+"');";
          dbase.query(sql, (err,result)=>{
          if(err) throw err; 

          let sql = "SELECT * FROM utilizadores WHERE nome_cafe='"+nome_cafe+"';"
              dbase.query(sql, (err,result)=>{
                if(err) throw err; 
                
                let playerId=result[0].id;
               
                //verifica se ha jogadores associados ao jogo
               
               let sql = "SELECT * FROM utilizadores;";
               dbase.query(sql, (err,result)=>{
                if(err) throw err; 
        
                  let sql = "INSERT INTO dias (`id_player`,`dia`,`temperatura`) VALUES ('"+playerId+"','"+"1"+"','"+39+"');"
                  
                  dbase.query(sql, (err,result)=>{
                  if(err) throw err; 

                      let sql = "INSERT INTO produtos (`id_produto`,`id_player`,`nome_produto`,`preco`,`quantidade`) VALUES ('"+"1"+"','"+playerId+"','"+'Coffee Cup'+"','"+1+"','"+0+"');"
                      dbase.query(sql, (err,result)=>{
                        if(err) throw err; 
                        let sql = "INSERT INTO produtos (`id_produto`,`id_player`,`nome_produto`,`preco`,`quantidade`) VALUES ('"+"2"+"','"+playerId+"','"+'Milk'+"','"+1+"','"+0+"');"
                        dbase.query(sql, (err,result)=>{
                          if(err) throw err; 
                          let sql = "INSERT INTO produtos (`id_produto`,`id_player`,`nome_produto`,`preco`,`quantidade`) VALUES ('"+"3"+"','"+playerId+"','"+'Sugar'+"','"+1+"','"+0+"');"
                          dbase.query(sql, (err,result)=>{
                            if(err) throw err; 
                            let sql = "INSERT INTO produtos (`id_produto`,`id_player`,`nome_produto`,`preco`,`quantidade`) VALUES ('"+"4"+"','"+playerId+"','"+'Coffee'+"','"+2+"','"+0+"');"
                            dbase.query(sql, (err,result)=>{
                              if(err) throw err;
                              let sql = "INSERT INTO produtos (`id_produto`,`id_player`,`nome_produto`,`preco`,`quantidade`) VALUES ('"+"5"+"','"+playerId+"','"+'Croissant'+"','"+3+"','"+0+"');"
                              dbase.query(sql, (err,result)=>{
                                if(err) throw err; 
                              let sql = "INSERT INTO receita (`id_produto`,`id_player`,`quantidade_produto`,`quantidade_produto_atual`) VALUES ('"+"2"+"','"+playerId+"','"+0+"','"+0+"');"
                              dbase.query(sql, (err,result)=>{
                                if(err) throw err;
                                let sql = "INSERT INTO receita (`id_produto`,`id_player`,`quantidade_produto`,`quantidade_produto_atual`) VALUES ('"+"3"+"','"+playerId+"','"+0+"','"+0+"');"
                                dbase.query(sql, (err,result)=>{
                                  if(err) throw err;
                                  let sql = "INSERT INTO receita (`id_produto`,`id_player`,`quantidade_produto`,`quantidade_produto_atual`) VALUES ('"+"4"+"','"+playerId+"','"+0+"','"+0+"');"
                                  dbase.query(sql, (err,result)=>{
                                    if(err) throw err;
                                    let sql = "INSERT INTO pedidos_outono (`id_player`,`pedido`) VALUES ('"+playerId+"','"+'Coffee'+"');"
                                    dbase.query(sql, (err,result)=>{
                                      if(err) throw err;
                                      let sql = "INSERT INTO pedidos_outono (`id_player`,`pedido`) VALUES ('"+playerId+"','"+'Milk'+"');"
                                      dbase.query(sql, (err,result)=>{
                                        if(err) throw err;
                                        let sql = "INSERT INTO pedidos_outono (`id_player`,`pedido`) VALUES ('"+playerId+"','"+'Croissant'+"');"
                                        dbase.query(sql, (err,result)=>{
                                          if(err) throw err;
                    });
                  res.send({"ack":1});
                }); 
          });
    });
  });
})})})})})})})})})})}});});

app.get("/getInformation/:id", (req,res) => {
    let id_user = req.params.id;
  
    let sql = "SELECT * FROM produtos JOIN dias ON produtos.id_player=dias.id_player JOIN utilizadores ON produtos.id_player=utilizadores.id WHERE produtos.id_player ='"+id_user+"';"
    dbase.query(sql, (err,result)=>{
      if(err) throw err; 
      res.send(result);
  });

});

app.get("/getProducts/:id", (req,res) => {
  let id_user = req.params.id;
  let sql = "SELECT * FROM produtos WHERE id_player='"+id_user+"';"

  dbase.query(sql, (err,result)=>{
    if(err) throw err; 
    res.send(result);
});

});

app.get('/getProdutos/:id',(req,res)=>{

  let id_user = req.params.id;

  let sql = "SELECT * FROM produtos  WHERE id_player = '"+id_user+"';"

  dbase.query(sql, (err,result)=>{
  if(err) throw err;
  res.send(result);

  });
});

app.post("/enviarCompras",(req,res) => {
  let id_user = req.body.id;
  let compra = req.body.compra;
  let id_produto = req.body.id_produto;

  let sql = "UPDATE produtos SET quantidade = '"+compra+"' WHERE id_player = '"+id_user+"' AND id_produto = '"+id_produto+"';"
  dbase.query(sql, (err,result)=>{
    if(err) throw err; 
    res.send(result);
});
});

app.post("/enviarDinheiro",(req,res) => {
  let id_user = req.body.id;
  let dinheiro_atual = req.body.dinheiro_atual;

  let sql = "UPDATE utilizadores SET dinheiro_atual = '"+dinheiro_atual+"' WHERE id = '"+id_user+"';"
  dbase.query(sql, (err,result)=>{
    if(err) throw err; 
    res.send(result);
});
});

app.post("/enviarNovasInformacoes",(req,res) => {
  let id_user = req.body.id;
  let quantidade = req.body.quantidade;
  let id_produto = req.body.id_produto;

  let sql = "UPDATE produtos SET quantidade = '"+quantidade+"' WHERE id_player = '"+id_user+"' AND id_produto = '"+id_produto+"';"
  dbase.query(sql, (err,result)=>{
    if(err) throw err; 
    res.send(result);
});
});

app.get('/getPedidos/:id',(req,res)=>{
  let id_user = req.params.id;

  let sql = "SELECT * FROM pedidos_outono  WHERE id_player = '"+id_user+"';"

    dbase.query(sql, (err,result)=>{
       if(err) throw err; 

        res.send(result);

    });

}); 

app.post('/enviarNovasInformacoesXP', (req,res) => {
  let id_user = req.body.id;
  let xp = req.body.xp;

  let sql = "UPDATE utilizadores SET xp = '"+xp+"' WHERE id = '"+id_user+"';"
  dbase.query(sql, (err,result)=>{
    if(err) throw err; 
    res.send(result);
});
})

app.post('/enviarNovasInformacoesEstacao', (req,res) => {
  let id_user = req.body.id;
  let estacao = req.body.estacao;

  let sql = "UPDATE utilizadores SET estacao = '"+estacao+"' WHERE id = '"+id_user+"';"
  dbase.query(sql, (err,result)=>{
    if(err) throw err; 
    res.send(result);
});
})

app.post('/enviarNovasInformacoesPedido', (req,res) => {
  let id_user = req.body.id;
  let pedido = req.body.pedido;

  let sql = "INSERT INTO pedidos_outono (`id_player`,`pedido`)  VALUES ('"+id_user+"','"+pedido+"');"
  dbase.query(sql, (err,result)=>{
    if(err) throw err; 
    res.send(result);
});
})

app.post('/enviarNovasInformacoesDia', (req,res) => {
  let id_user = req.body.id;
  let dia = req.body.dia;
  let temperatura = req.body.temperatura;

  let sql = "UPDATE dias SET dia = '"+dia+"' , temperatura = '"+temperatura+"' WHERE id_player = '"+id_user+"';"
  dbase.query(sql, (err,result)=>{
    if(err) throw err; 
    res.send(result);
});
})

app.post('/enviarNovasInformacoesProduto', (req,res) => {
  let id_user = req.body.id;
  let produto = req.body.produto;
  let id_produto = req.body.id_produto;
  let quantidade = req.body.quantidade;
  let preco = req.body.preco;

  let sql = "INSERT INTO produtos (`id_produto`,`id_player`,`nome_produto`,`preco`,`quantidade`) VALUES ('"+id_produto+"','"+id_user+"','"+produto+"','"+preco+"','"+quantidade+"');"
  dbase.query(sql, (err,result)=>{
    if(err) throw err; 
    res.send(result);
});
})

app.get('/getRecipe/:id',(req,res)=>{

  let sql = "SELECT * FROM receita";

    dbase.query(sql, (err,result)=>{
       if(err) throw err; 

        res.send(result);

    });

}); 

app.post("/enviarReceita",(req,res) => {
  let id = req.body.id;
  let id_produto = req.body.id_produto;
  let quantidade_produto_atual = req.body.quantidade_produto_atual;

  let sql = "UPDATE receita SET quantidade_produto_atual = "+quantidade_produto_atual+" WHERE id_player = "+id+" AND id_produto = "+id_produto+";"
  dbase.query(sql, (err,result)=>{
    if(err) throw err; 
    res.send(result);
});
});

app.post("/enviarNovasInformacoesDinheiro",(req,res) => {
  let id = req.body.id;
  let dinheiro = req.body.dinheiro;

  let sql = "UPDATE utilizadores SET dinheiro_inicio_dia = "+dinheiro+" WHERE id = "+id+";"
  dbase.query(sql, (err,result)=>{
    if(err) throw err; 
    res.send(result);
});
});

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})